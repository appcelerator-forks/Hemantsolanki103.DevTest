/*
*-----------------HOME SCREEN------------------
*/
'use strict';

import React, {Component} from 'react';
import {Root} from "native-base";
import {
    Platform,
    StyleSheet,
    Text,
    View,
    Image,
    TextInput,
    Keyboard,
    KeyboardAvoidingView,
    TouchableOpacity,
    Alert,
    FlatList,
    NetInfo,
    BackHandler,
    Dimensions
} from 'react-native';
import {
    Container,
    Header,
    Content,
    Card,
    CardItem,
    Thumbnail,
    Button,
    Icon,
    Left,
    Body,
    Right,
    List,
    Title,
    H3
} from 'native-base';

var ceil = require('math-ceil');
const rowHeight = Global.DEVICE_HEIGHT * 0.44;
const thumbHeight = rowHeight * 0.70;
const footerHeight = rowHeight * 0.30;
import Toast, {DURATION} from 'react-native-easy-toast'
import Global from "../lib/Global.js"
import Communicator from "../lib/Global.js"
import LoadingSpinner from '../loadingSpinner/index.js'
import FlatListItem from '../itemContainer/flatListItem.js'
//import Communicator from "../lib/Communicator.js"
import WebServiceHandler from 'react-native-web-service-handler';
import Spinner from 'react-native-loading-spinner-overlay';
import SimplePicker from "react-native-simple-picker";
import YouTube, {YouTubeStandaloneIOS, YouTubeStandaloneAndroid} from 'react-native-youtube';
import ImageLoad from 'react-native-image-placeholder';
import {SinglePickerMaterialDialog} from 'react-native-material-dialog';
import Moment from 'moment';
import Orientation from 'react-native-orientation';
import {UltimateListView} from 'react-native-ultimate-listview'

var playListTitleArray = ["All Videos"];
var playListTitleid = [0];
var index = [0];
const count = 0;
const {width, height} = Dimensions.get('window')

var json = {
    "value": 0,
    "label": "All Videos",
    "selected": true
};

export default class Home extends Component {
    // static navigationOptions = ({navigation, props, state}) => ({ })
    constructor(props) {
        super(props);
        this.state = {
            showLoader: false,
            videoId: "",
            isLoadMore: true,
            selectedOption: 'All Videos',
            playListTitle: [],
            playListId: [],
            index: [],
            token: "",
            play_list_id: "",
            totalRecords: 0,
            response: [],
            scrolledSinglePickerSelectedItem: json,
            scrolledSinglePickerVisible: false,
            contentHeight: 0,
            refreshing: false,
            pickerValue: [
                {
                    "id": 0,
                    "name": "All Videos"
                }
            ]
        };

        this.token = "";

        this.getPlayList = this
            .getPlayList
            .bind(this);
        this.getPlayListItemAndAllVideo = this
            .getPlayListItemAndAllVideo
            .bind(this);
        this._handleSave = this
            ._handleSave
            .bind(this);
    }

    sleep = time => new Promise(resolve => setTimeout(() => resolve(), time))
    _keyExtractor = (item, index) => index;
    _renderItem = ({item, index, separator}) => {

        return (<ListItem item={item} index={index} onPressItem={this._onPressItem}/>)
    };

    onPressItem = (type, index, item) => {
        if (Global.isConnected) {
            const {navigate} = this.props.navigation;
            if (item.contentDetails.hasOwnProperty('upload')) {
                navigate('Video', {videoId: item.contentDetails.upload.videoId});
            } else {
                navigate('Video', {videoId: item.contentDetails.videoId});
            }
        } else {
            this
                .refs
                .toast
                .show("Please check your network connections.");
        }
    }

    renderPaginationFetchingView = () => (<LoadingSpinner height={height * 0.2} text="loading..."/>)

    componentDidMount() {
        BackHandler.addEventListener('hardwareBackPress', this.handleBackButton);
        Orientation.lockToPortrait();
        this.getPlayList(this.refs.toast);
       
        //this.getPlayListItemAndAllVideo(true, "", false);

    }

    componentWillUnmount() {
        BackHandler.removeEventListener('hardwareBackPress', this.handleBackButton);
    }
    handleBackButton = () => {
        Alert.alert('Exit App', 'Exiting the application?', [
            {
                text: 'Cancel',
                onPress: () => console.log('Cancel Pressed'),
                style: 'cancel'
            }, {
                text: 'OK',
                onPress: () => BackHandler.exitApp()
            }
        ], {cancelable: false})
        return true;
    }
    getPlayList(Toast) {
        const url = "https://www.googleapis.com/youtube/v3/playlists?part=snippet%2CcontentDetails&ma" +
                "xResults=" + 50 + "&pageToken=&channelId=UC9A2jrMXixjK4y3VqQq_W9w&key=AIzaSyB3n7oA5qxK8vdesNIOeRIQZ" +
                "PVko0yvbrc";
        fetch(url).then((response) => response.json()).then((responseJson) => {
            try {
                playListTitleArray = ["All Videos"];
                playListTitleid = [0];
                index = [0];
                var ind = 0;
                for (var i = 0; i < responseJson.items.length; i++) {
                    console.log("------  " + responseJson.items.length)
                    playListTitleArray.push(responseJson.items[i].snippet.title);
                    playListTitleid.push(responseJson.items[i].id);
                    index.push(++ind);
                }
                this.setState({playListTitle: playListTitleArray, playListId: playListTitleid, index: index});

            } catch (e) {
                this.setState({showLoader: false});
                console.log("Error Communicator: " + e);
            } finally {}
        }).catch((e) => {
            this.setState({showLoader: false});
            console.log("Error Communicator: " + e.message);
            if (e.message == "Network request failed") {
                this
                    .refs
                    .toast
                    .show("Please check your internet connection.");
            }
        });
    }

    _handleSave = () => {
        if (Platform.OS == 'ios') {
            this
                .refs
                .picker
                .show();
        } else {
            this.setState({scrolledSinglePickerVisible: true});
        }
    };
    getPlayListItemAndAllVideo(isAllCategory, playListID, isLoadMore, callback) {
        if (isLoadMore) {
            this.setState({showLoader: true});
        }
        if (isAllCategory) {
            var url = "https://www.googleapis.com/youtube/v3/activities?part=snippet%2CcontentDetails&m" +
                    "axResults=" + 20 + "&pageToken=" + this.token + "&channelId=UC9A2jrMXixjK4y3VqQq_W9w&key=AIzaSyB3n7oA5qxK8vdesNIOeRIQZPVko0yvbrc";
        } else {
            var url = "https://www.googleapis.com/youtube/v3/playlistItems?part=snippet%2CcontentDetail" +
                    "s&maxResults=" + 20 + "&pageToken=" + this.token + "&playlistId=" + playListID + "&key=AIzaSyB3n7oA5qxK8vdesNIOeRIQZPVko0yvbrc";
        }
        fetch(url).then((response) => response.json()).then((responseJson) => {
            try {
                this.setState({response: responseJson.items})

                var totalPage = responseJson.pageInfo.totalResults / 20;
                totalPage = ceil(totalPage);
                this.setState({totalRecords: totalPage})
                if (responseJson.hasOwnProperty('nextPageToken')) {

                    this.setState({token: responseJson.nextPageToken})
                    this.token = responseJson.nextPageToken;
                } else {
                    this.setState({token: ""})
                    this.token = "";
                }
                callback(responseJson.items, this.state.totalRecords, this);

            } catch (e) {
                if (isLoadMore) {
                    this.setState({showLoader: false});
                }
                console.log("Error Communicator: " + e);
            } finally {}

        }).catch((e) => {
            if (isLoadMore) {
                this.setState({showLoader: false});
            }
            if (e.message == "Network request failed") {
                this
                    .refs
                    .toast
                    .show("Please check your internet connection.");
            }
            console.log("Error Communicator: " + e);
        });
    } 

    onFetch = async(page = 1, startFetch, abortFetch) => {
        try {
            console.log('-------Coming------- ' + page)
            let pageLimit = 20;
            var isLoaderRequired = false;
            if (page == 1) {
                isLoaderRequired = true;
                this.setState({token: ""});
                this.token = "";

                console.log("---------this.state.token---------" + this.token)
            } else {
                isLoaderRequired = false;
            }
            if (this.state.play_list_id == "") {
                this
                    .getPlayListItemAndAllVideo(true, "", isLoaderRequired, function callback(res, totalRecords, ths) {

                        if (page > totalRecords) {
                            ths.setState({response: []});
                        } else {
                            ths.setState({response: res});
                        }
                        startFetch(ths.state.response, pageLimit)
                    });
            } else {
                this
                    .getPlayListItemAndAllVideo(false, this.state.play_list_id, isLoaderRequired, function callback(res, totalRecords, ths) {

                        if (page > totalRecords) {
                            ths.setState({response: []});
                        } else {
                            ths.setState({response: res});
                        }
                        startFetch(ths.state.response, pageLimit);
                    });
            }
            // Simulate the network loading in ES7 syntax (async/await)
            await this.sleep(3000)

            if (isLoaderRequired) {
               this.setState({showLoader: false});
           } 

        } catch (err) {
            abortFetch()
            if (isLoaderRequired) {
                this.setState({showLoader: false});
            }
            console.error(err)
        }
    }
    renderItem = (item, index, separator) => {

        return (<FlatListItem item={item} index={index} onPress={this.onPressItem}/>)

    }

    render() {
        const {navigate} = this.props.navigation;
        return (
            <Container style={{
                backgroundColor: "white"
            }}>
                <Header
                    style={{
                    backgroundColor: "#f8f8f8"
                }}>
                    <Left style={{
                        flex: 0.25
                    }}></Left>
                    <Body
                        style={{
                        flex: 0.50,
                        alignItems: "center"
                    }}>
                        <Title
                            style={{
                            color: "#282828"
                        }}>Home</Title>
                    </Body>
                    <Right
                        style={{
                        flex: 0.20,
                        height: 44
                    }}>
                        <View
                            style={{
                            height: "100%",
                            width: "100%",
                            alignItems: "flex-end",
                            justifyContent: "center",
                            flexDirection: "row"
                        }}>
                            <TouchableOpacity
                                style={{
                                height: "100%",
                                left: 0,
                                width: "50%",
                                alignItems: "center",
                                justifyContent: "center"
                            }}
                                onPress={this._handleSave}>
                                <Image source={require("../assets/images/cat.png")}/>
                            </TouchableOpacity>
                            <TouchableOpacity
                                style={{
                                height: "100%",
                                right: 0,
                                width: "50%",
                                justifyContent: "center"
                            }}
                                onPress={() => Alert.alert('CDN App', 'Are you sure want to logout?', [
                                {
                                    text: 'Yes',
                                    onPress: () => this
                                        .props
                                        .navigation
                                        .goBack()
                                }, {
                                    text: 'Cancel',
                                    onPress: () => console.log('Cancel Pressed'),
                                    style: 'cancel'
                                }
                            ], {cancelable: false})}>
                                <Image
                                    style={{
                                    alignSelf: "flex-end"
                                }}
                                    source={require("../assets/images/logout.png")}/>
                            </TouchableOpacity>
                        </View>
                    </Right>
                </Header>
                <View
                    style={{
                    top: 0,
                    height: 40,
                    justifyContent: 'center',
                    borderBottomWidth: 1,
                    borderBottomColor: "#D0CFD1",
                    backgroundColor: "white",
                    zIndex: 10
                }}>
                    <Text
                        style={{
                        width: "90%",
                        alignSelf: "center",
                        fontWeight: "normal",
                        fontSize: 15
                    }}>
                        {this.state.selectedOption}
                    </Text>
                </View>
                <Spinner
                    visible={this.state.showLoader}
                    textContent={"Loading..."}
                    textStyle={{
                    color: '#FFF'
                }}/>
                <UltimateListView
                    ref={(c) => this._input = c}
                    key={'list'}
                    onFetch={this.onFetch}
                    keyExtractor={(item, index) => `${index} - ${item}`}
                    refreshableMode="advanced"
                    item={this.renderItem}
                    numColumns={1}/>
                <SimplePicker
                    ref={"picker"}
                    options={this.state.index}
                    buttonStyle={{
                    color: "#027AFE"
                }}
                    labels={this.state.playListTitle}
                    onSubmit={(option) => {
                    if (Global.isConnected) {
                        this
                            ._input
                            .scrollToIndex({index: 0, animated: true});
                        if (option == 0) {
                            console.log(" OPTION1 ----" + option);
                            this.setState({selectedOption: playListTitleArray[option], play_list_id: "", token: ""});
                            this.token = "";
                        } else {
                            this.setState({selectedOption: playListTitleArray[option], play_list_id: playListTitleid[option], token: ""});
                            this.token = "";
                            console.log(" OPTION2 ----" + playListTitleid[option]);
                        }
                        setTimeout(() => {
                            this
                                ._input
                                .refresh();
                        }, 400)
                    } else {
                        this
                            .refs
                            .toast
                            .show("Please check your network connections.");
                    }
                }}/>
                <SinglePickerMaterialDialog
                    title={'Select Category'}
                    scrolled
                    colorAccent={'#02A0E3'}
                    items=
                    {this.state.playListTitle.map((row, index) => ({value: index, label: row}))}
                    visible={this.state.scrolledSinglePickerVisible}
                    selectedItem={this.state.scrolledSinglePickerSelectedItem}
                    onCancel={() => this.setState({scrolledSinglePickerVisible: false})}
                    onOk={(result) => {
                    this.setState({scrolledSinglePickerVisible: false});
                    if (Global.isConnected) {
                        console.log(JSON.stringify(result));
                        this.setState({selectedOption: result.selectedItem.label});
                        this.setState({scrolledSinglePickerSelectedItem: result.selectedItem});
                        this
                            ._input
                            .scrollToIndex({index: 0, animated: true});
                        if (result.selectedItem.value == 0) {
                            this.setState({selectedOption: result.selectedItem.label, play_list_id: "", token: ""});
                            this.token = "";
                        } else {
                            this.setState({
                                selectedOption: result.selectedItem.label,
                                play_list_id: playListTitleid[result.selectedItem.value],
                                token: ""
                            });
                            this.token = "";
                            console.log(" OPTION2 ----" + playListTitleid[result.selectedItem.value]);
                        }
                        setTimeout(() => {
                            this
                                ._input
                                .refresh();
                        }, 400);
                    } else {
                        this
                            .refs
                            .toast
                            .show("Please check your network connections.");
                    }
                }}/>
                <Toast
                    ref="toast"
                    style={{
                    backgroundColor: 'black'
                }}
                    position='bottom'
                    positionValue={100}
                    fadeInDuration={500}
                    fadeOutDuration={1500}
                    opacity={0.8}
                    textStyle={{
                    color: 'white'
                }}/>
            </Container>
        );
    }
}

const styles = StyleSheet.create({
    headerVW: {
        backgroundColor: "#333333",
        borderBottomWidth: 0.3,
        borderBottomColor: "#6A6A6A"
    },
    leftHeadBtn: {
        backgroundColor: "transparent",
        width: 50,
        justifyContent: "flex-end",
        alignItems: "center"
    },
    rightHeadBtn: {
        backgroundColor: "transparent",
        width: 40,
        justifyContent: "flex-end",
        alignItems: "center"
    }
});
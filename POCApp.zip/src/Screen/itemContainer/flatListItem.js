import React, {PureComponent} from 'react'
import {
  StyleSheet,
  View,
  Alert,
  TouchableOpacity,
  Image,
  TouchableHighlight
} from 'react-native'
import {
  Button,
  ListItem,
  Left,
  Right,
  Body,
  Thumbnail,
  Text,
  Icon,
  Card,
  CardItem
} from 'native-base'

import ImageLoad from 'react-native-image-placeholder';
import Moment from 'moment';
const rowHeight = Global.DEVICE_HEIGHT * 0.44;
const thumbHeight = rowHeight * 0.70;
const footerHeight = rowHeight * 0.30;
import Toast, {DURATION} from 'react-native-easy-toast'
import Global from "../lib/Global.js"

export default class Example extends PureComponent {
  constructor(props) {
    super(props)
  }

  render() {

    const item = this.props.item;

    var date = item.snippet.publishedAt;
    Moment.locale('en');
    var description = item.snippet.description;
    if (description) {
      description = "No Description Avaliable"
    }
    var flag = false;
    if (item.snippet.hasOwnProperty('thumbnails')) {
      if (item.snippet.thumbnails.hasOwnProperty('standard')) {
        var image = item.snippet.thumbnails.standard.url
      } else if (item.snippet.thumbnails.hasOwnProperty('high')){
        var image = item.snippet.thumbnails.high.url
      }else{
        var image = item.snippet.thumbnails.small.url
      }
      flag = true;
    } else {
      flag = false;
      var image = "none"
    }

    let card;
    if (flag) {
      card = (
        <Card
          style={{
          height: rowHeight,
          width: "90%",
          alignSelf: "center",
          alignItems: "stretch"
        }}>
          <View
            style={{
            height: "100%",
            flexDirection: 'column'
          }}>

            <TouchableOpacity
              button
              style={{
              height: "100%",
              width: "100%"
            }}
              onPress={() => this.props.onPress('chat', this.props.index, this.props.item)}>
              {flag
                ? <ImageLoad
                    style={{
                    height: thumbHeight,
                    width: "100%"
                  }}
                    placeholderSource={require("../assets/images/defaultImage.png")}
                    loadingStyle={{
                    size: 'small',
                    color: '#26AFFD'
                  }}
                    source={{
                    uri: (flag)
                      ? image
                      : "../assets/images/defaultImage.png"
                  }}/>
                : <ImageLoad
                  style={{
                  height: thumbHeight,
                  width: "100%"
                }}
                  placeholderSource={require("../assets/images/defaultImage.png")}
                  loadingStyle={{
                  size: 'small',
                  color: '#26AFFD'
                }}/>
}

              <View
                style={{
                top: 6 * Global.HEIGHT_FACTOR,
                height: "26%",
                width: "94%",
                alignSelf: "center",
                flexDirection: 'column',
                justifyContent: 'space-between'
              }}>
                <Text
                  numberOfLines={1}
                  style={{
                  fontSize: 16,
                  width: "100%",
                  textAlign: "left"
                }}>
                  {item.snippet.title}</Text>
                <Text
                  numberOfLines={2}
                  style={{
                  fontSize: 13,
                  color: "grey",
                  width: "100%",
                  textAlign: "left"
                }}>
                  {description}
                </Text>
                <Text
                  numberOfLines={1}
                  style={{
                  fontSize: 11,
                  color: "grey",
                  width: "100%",
                  textAlign: "left"
                }}>
                  {Moment(date).format('d-MMM-YYYY')}
                </Text>
              </View>
            </TouchableOpacity>
          </View>
        </Card>
      )
    } else {
      return false;
    }
    return (card);
  }
}

/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */
/*
* All File Import Here
*/
import React, {Component} from 'react';
import {Root} from "native-base";
import {
    Platform,
    StyleSheet,
    Text,
    View,
    Image,
    TextInput,
    Keyboard,
    KeyboardAvoidingView,
    TouchableOpacity,
    NetInfo,
    Alert
} from 'react-native';
import {
    Container,
    Content,
    Header,
    Left,
    Right,
    Body,
    Title
} from "native-base";
import Orientation from 'react-native-orientation';

import Toast, {DURATION} from 'react-native-easy-toast'
import Global from "../lib/Global.js"
import Communicator from "../lib/Communicator.js"
import SplashScreen from "react-native-smart-splash-screen";
import Display from "react-native-display";
// var soap = require('soap-everywhere');

Platform.select({
    ios:{
    },
    android: 'Double tap R on your keyboard to reload,\nShake or press menu button for dev men' +
            'u'
});

export default class Login extends Component {
    static navigationOptions = {
        title: 'Sign In'
    }
    constructor(props) {
        super(props);
        this.state = {
            showPass: true,
            press: false,
            username: "",
            password: "",
            visible: false,
            enable:false
        };
        this.focusNextField = this
            .focusNextField
            .bind(this);
        this.inputs = {};

    }

    focusNextField(key) {
        this
            .inputs[key]
            .focus();
    }

    _submitForm = () => {
        const {username, password} = this.state;

        const blankEmailValid = username && username.length > 0
            ? true
            : false;
        const emailValid = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(username);
        const blankPasswordValid = password && password.length > 0
            ? true
            : false;
        const passwordLengthValid = password && password.length >= 6
            ? true
            : false;
        if (blankEmailValid) {
            if (emailValid) {
                if (blankPasswordValid) {
                    if (passwordLengthValid) {
                        if (Global.isConnected) {
                            const {navigate} = this.props.navigation;
                            navigate("Home");
                        } else {
                            this
                                .refs
                                .toast
                                .show("Please check your internet connection.");
                        }

                    } else {
                        this
                            .refs
                            .toast
                            .show("Password should have atleast 6 characters");
                    }
                } else {
                    this
                        .refs
                        .toast
                        .show("Pleaser enter password");
                }
            } else {
                this
                    .refs
                    .toast
                    .show("Please enter valid Email");
            }
        } else {
            this
                .refs
                .toast
                .show('Please enter email address');
        }
    }
    componentDidMount() {

        Orientation.lockToPortrait();

        SplashScreen.close({animationType: SplashScreen.animationType.scale, duration: 850, delay: 500});
        this.setState({enable:true});

    }
    render() {
        return (
            <Container>
                <Header style={styles.headerVW}>
                    <Left style={{
                        flex: 0.25
                    }}></Left>
                    <Body
                        style={{
                        alignItems: "center"
                    }}>
                        <Title
                            style={{
                            color: "#282828"
                        }}>Sign In</Title>
                    </Body>
                    <Right style={{
                        flex: 0.25
                    }}></Right>
                </Header>
                <View
                    scrollEnabled={false}
                    onStartShouldSetResponderCapture={e => {
                    console.log("e.native " + e.nativeEvent.target);
                    if (e.nativeEvent.target != 12 && e.nativeEvent.target != 15 && e.nativeEvent.target != 14 && e.nativeEvent.target != 10 && e.nativeEvent.target != 16 && e.nativeEvent.target != 13) {
                        Keyboard.dismiss();
                    }
                }}>
                    <Display
                        enable={this.state.enable}
                        enterDuration={1500}
                        enter="fadeInUp"
                        style={styles.logoVW}>
                        <Image
 
                            source={require("../assets/images/cdnwhite_logo_trans.png")}/>
                    </Display>
                    <View style={styles.userTextVW}>
                        <Image source={require("../assets/images/user.png")} style={styles.inlineImg}/>
                        <TextInput
                            style={styles.input}
                            placeholder="Email"
                            autoCorrect={false}
                            autoCapitalize={"none"}
                            returnKeyType={"next"}
                            placeholderTextColor="grey"
                            underlineColorAndroid="transparent"
                            onChangeText=
                            { username => this.setState({username}) }
                            value={this.state.username}
                            ref=
                            { input => { this.inputs["one"] = input; } }
                            onSubmitEditing=
                            { () => { this.focusNextField("two"); } }/>
                    </View>
                    < View style={styles.pwdTextVW}>
                        <Image source={require("../assets/images/password.png")} style={styles.pwdImg}/>
                        <TextInput
                            style={styles.pwdTF}
                            placeholder="Password"
                            secureTextEntry={true}
                            autoCorrect={false}
                            autoCapitalize={"none"}
                            returnKeyType={"done"}
                            placeholderTextColor="grey"
                            underlineColorAndroid="transparent"
                            onChangeText=
                            { password => this.setState({password}) }
                            value={this.state.password}
                            ref=
                            { input => { this.inputs["two"] = input; } }
                            onSubmitEditing=
                            { () => { this.focusNextField("two"); } }/>
                    </View>

                    <TouchableOpacity style={styles.loginBtn} onPress={this._submitForm}>
                        <Text style={styles.logintext}>Sign In</Text>
                    </TouchableOpacity>
                    <Toast
                        ref="toast"
                        style={{
                        backgroundColor: 'black'
                    }}
                        position='bottom'
                        positionValue={150}
                        fadeInDuration={750}
                        fadeOutDuration={1000}
                        opacity={0.8}
                        textStyle={{
                        color: 'white'
                    }}/>
                </View>
            </Container>
        );
    }
}
const styles = StyleSheet.create({
    headerVW: {
        backgroundColor: "#f8f8f8"
    },
    logoVW: {
        top: 60 * Global.HEIGHT_FACTOR,
        // justifyContent: 'center',
        alignSelf: 'center'
    },
    userTextVW: {

        top: 120 * Global.HEIGHT_FACTOR,
        flexDirection: "row",
        backgroundColor: "white",
        left: 0,
        right: 0,
        height: 40 * Global.HEIGHT_FACTOR,
        alignItems: "center"
    },
    inlineImg: {
        left: 15 * Global.HEIGHT_FACTOR
    },
    input: {
        left: 30 * Global.HEIGHT_FACTOR,
        //backgroundColor: "rgba(255, 255, 255, 0.4)",
        width: "80%",
        height: 40 * Global.HEIGHT_FACTOR,
        alignSelf: "center",
        paddingLeft: 0,
        color: "#282828",
        fontSize: 14 * Global.HEIGHT_FACTOR
    },
    pwdTextVW: {
        top: 121 * Global.HEIGHT_FACTOR,
        flexDirection: "row",
        backgroundColor: "white",
        left: 0,
        right: 0,
        height: 40 * Global.HEIGHT_FACTOR,
        alignItems: "center"
    },
    pwdImg: {
        left: 15 * Global.HEIGHT_FACTOR
    },
    pwdTF: {
        left: 30 * Global.HEIGHT_FACTOR,
        width: "80%",
        height: 40 * Global.HEIGHT_FACTOR,
        alignSelf: "center",
        paddingLeft: 0,
        color: "#282828",
        fontSize: 14 * Global.HEIGHT_FACTOR
    },
    loginBtn: {
        height: 40 * Global.HEIGHT_FACTOR,
        width: "100%",
        backgroundColor: "#D5A40A",
        top: 150 * Global.HEIGHT_FACTOR,
        justifyContent: "center",
        alignItems: "center"
    },
    logintext: {
        fontSize: 16 * Global.HEIGHT_FACTOR,
        color: "#FFFFFF"
    }
});
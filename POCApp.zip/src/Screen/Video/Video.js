/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */
/*
* All File Import Here
*/
import React, {Component} from 'react';
import {Root} from "native-base";
import {
    Platform,
    StyleSheet,
    Text,
    View,
    Image,
    TextInput,
    Keyboard,
    KeyboardAvoidingView,
    TouchableOpacity,
    Alert
} from 'react-native';
import {
    Container,
    Content,
    Header,
    Left,
    Right,
    Body,
    Title,
    Icon,
    Button
} from "native-base";

import Toast, {DURATION} from 'react-native-easy-toast'
import Global from "../lib/Global.js"
import YouTube, {YouTubeStandaloneIOS, YouTubeStandaloneAndroid} from 'react-native-youtube';
import Orientation from 'react-native-orientation';
import Spinner from 'react-native-loading-spinner-overlay';

export default class Login extends Component {
    static navigationOptions = {
        title: 'Video'
    }
    constructor(props) {
        super(props);
        this.state = {
            showPass: true,
            showLoader: false,
            fullscreen: false
        }
    }
    componentDidMount() {
        this.setState({showLoader: true});

        Orientation.lockToPortrait();

    }

    render() {
        const {state, navigate} = this.props.navigation;
        return (
            <Container>
                <Header
                    style={{
                    backgroundColor: "#f8f8f8"
                }}>
                    <Left style={{
                        flex: 0.15
                    }}>
                        <Button transparent onPress= {()=>{ this.props.navigation.goBack()}}>
                            <Icon name='ios-arrow-back'/>
                        </Button>
                    </Left>
                    <Body
                        style={{
                        flex: 0.70,
                        alignItems: "center"
                    }}>
                        <Title
                            style={{
                            color: "#282828"
                        }}>Video Details</Title>
                    </Body>
                    <Right
                        style={{
                        flex: 0.15,
                        height: 44
                    }}></Right>
                </Header>
                <YouTube
                    apiKey="AIzaSyB3n7oA5qxK8vdesNIOeRIQZPVko0yvbrc"
                    videoId={state.params.videoId}
                    play={true}
                    loop={false}
                    fullscreen={this.state.fullscreen}
                    style={{
                    alignSelf: 'stretch',
                    height: 300
                }}
                    onError={e => {
                    console.log("onError -- " + JSON.stringify(e));
                    if (e.error == "UNAUTHORIZED_OVERLAY") {
                        Orientation.lockToPortrait();
                        this
                            .props
                            .navigation
                            .goBack()
                    }
                    this.setState({error: e.error})
                }}
                    onReady={e => {
                    console.log("onReady -- " + e);
                    this.setState({showLoader: false});
                    this.setState({isReady: true});
                }}
                    onChangeState={e => {
                    console.log("onChangeState -- " + e.state);
                    this.setState({status: e.state});
                    if (e.state == "ended") {
                        console.log("DONE -- " + e.state);
                        Orientation.lockToPortrait();
                        this
                            .props
                            .navigation
                            .goBack()
                    }
                }}
                    onChangeQuality={e => this.setState({quality: e.quality})}
                    onChangeFullscreen={e => this.setState({fullscreen: e.isFullscreen})}
                    onProgress={e => this.setState({duration: e.duration, currentTime: e.currentTime})}/>
                <Spinner
                    visible={this.state.showLoader}
                    textContent={"Please Wait..."}
                    textStyle={{
                    color: '#FFF'
                }}/>
            </Container>
        );
    }
}
const styles = StyleSheet.create({
    headerVW: {
        backgroundColor: "#f8f8f8"
    }
})
/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React from "react";

import {Platform} from "react-native";
import {StackNavigator} from "react-navigation";

import Login from "./src/Screen/Login/Login.js"
import Home from "./src/Screen/Home/Home.js"
import Video   from "./src/Screen/Video/Video.js"
import Global from './src/Screen/lib/Global.js';
const AppNavigator = StackNavigator({
  Login: {
    screen: Login
  },
  Home: {
    screen: Home
  },
  Video: {
    screen: Video
  },
}, {
  initialRouteName: "Login",
  headerMode: "none"
});
export default AppNavigator;
/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */
console.disableYellowBox = true;
import React from "react";

import {Platform, Alert} from "react-native";
import {StackNavigator} from "react-navigation";

// import KeyboardManager from 'react-native-keyboard-manager'
// KeyboardManager.setToolbarPreviousNextButtonEnable(true);
import Login from "./src/Screen/Login/Login.js"
import Drawer from "./src/Screen/Drawer/Drawer.js"
import Notification from "./src/Screen/Notification/Notification.js"
import Supervisor from "./src/Screen/Supervisor/Supervisor.js"
import SupervisorDetail from "./src/Screen/SupervisorDetail/SupervisorDetail.js"

const AppNavigator = StackNavigator({
  Login: {
    screen: Login
  },
  Drawer: {
    screen: Drawer
  },
  Notification: {
    screen: Notification
  },
  Supervisor:{
    screen:Supervisor
  },
  SupervisorDetail:{
    screen:SupervisorDetail  
  }
}, {
   
  initialRouteName: "Login",
  headerMode: "none",
  navigationOptions: {
    gesturesEnabled: false
  }
});
export default AppNavigator;
import React, {Component, PropTypes} from "react";
import {TouchableOpacity, StyleSheet, Image, View, StatusBar} from "react-native";
import ExpandableList from 'react-native-expandable-section-flatlist';
import {responsiveHeight, responsiveWidth, responsiveFontSize} from 'react-native-responsive-dimensions';
import {Rating} from 'react-native-elements';

import {
    Container,
    Header,
    Title,
    Content,
    Footer,
    FooterTab,
    Button,
    Left,
    Right,
    Body,
    Icon,
    Text,
    ActionSheet,
    Badge,
    Card,
    Thumbnail,
    CardItem,
    Input,
    Item,
    Form,
    Label,
    ListItem,
    List,
    Segment,
    SwipeRow
} from "native-base";

const GLOBAL = require("../lib/Global.js");

import {SearchBar} from 'react-native-elements'
const workbenchData = [
    {
        title: 'ABCD',
        member: [
            {
                company: 'Company1',
                duration: '01-Nov-2017 To 01-Nov-2018'
            }, {
                company: 'Company2',
                duration: '01-Nov-2017 To 01-Nov-2018'
            }, {
                company: 'Company3',
                duration: '01-Nov-2017 To 01-Nov-2018'
            }, {
                company: 'Company4',
                duration: '01-Nov-2017 To 01-Nov-2018'
            }, {
                company: 'Company5',
                duration: '01-Nov-2017 To 01-Nov-2018'
            }, {
                company: 'Company6',
                duration: '01-Nov-2017 To 01-Nov-2018'
            }
        ]
    }
];
class SupervisorDetail extends React.Component {
 constructor(props) {
        super(props);
        this.state = {
            data: [],
            text: ""
        };
    }

    _onPress = (type, i) => {
        if (type == "image") {
            this
                .props
                .navigation
                .navigate("SupervisorDetail"); 
        }
    }


    componentDidMount() {
        console.log("--------2--------")
        setTimeout(() => {
            this.setState({data: workbenchData})
        }, 100);
    }
    _renderRow = (rowItem, rowId, sectionId) => (
        <View
            style={{
            borderBottomColor: "#dcdcdc",
            borderBottomWidth: 0.5,
        }}>
            <Text
                style={{
                marginTop: 8,
                marginBottom: 8,
                left: responsiveWidth(3),
                fontSize: responsiveFontSize(1.5)
            }}>{rowItem.company}</Text>
            <Text
                style={{
                marginBottom: 8,
                left: responsiveWidth(3),
                fontSize: responsiveFontSize(1.5)
            }}>Duration: {rowItem.duration}</Text>
           
        </View>
    );
    _renderSection = (section, sectionId) => (
        <View
            style={{
           // height: responsiveHeight(27.72),
            borderBottomColor: "#dcdcdc",
            borderBottomWidth: 0.5
        }}>
            <Text
                style={{
                marginTop: 8,
                marginBottom: 8,
                left: responsiveWidth(3),
                fontWeight: "400",
                fontSize: responsiveFontSize(2.2),
            }}>Company</Text>
            <Text
                style={{
                marginBottom: 8,
                left: responsiveWidth(3),
                fontSize: responsiveFontSize(2)
            }}>01-Nov-1015 To 01-Nov-2016</Text>
            <View
                style={{
                height: 1,
                width: "100%",
                backgroundColor: "#DFDFDF",
            }}></View>
        </View>
    );
    render() {
        return (
            <Container style={styles.container}>
                <Header style={styles.header}>
                    <Left style={{
                        flex: 0.2
                    }}>
                        <Button
                            transparent
                            style={{
                            width: "100%",
                            height: "100%"
                        }}
                            onPress={() => this.props.navigation.goBack()}>
                            <Icon
                                name="ios-arrow-back"
                                style={{
                                color: "white"
                            }}/>
                        </Button>
                    </Left>
                    <Body
                        style={{
                        flex: 0.8,
                        alignSelf: "center"
                    }}>
                        <Title style={styles.headerTitle}>
                            Supervisor Detail
                        </Title>
                    </Body>
                    <Right
                        style={{
                        right: 0,
                        flex: 0.2
                    }}></Right>
                </Header>
                <StatusBar barStyle="light-content"/>
                <View
                    style={{
                    top: 0,
                    height: "24%",
                    backgroundColor: "#ededed",
                    justifyContent: "center",
                    alignItems: "center"
                }}>
                    <Image
                    source={require("../assets/images/send.png")}
                        style={{
                        
                        height: responsiveHeight(16.20),
                        width: responsiveHeight(16.20),
                        borderRadius: responsiveHeight(16.20) / 2,
                        backgroundColor: "red"
                    }}></Image>
                    <Text
                        style={{
                        position: "absolute",
                        right: "3%",
                        top: responsiveHeight(16.5),
                        fontSize: responsiveFontSize(1.6),
                        color: "black"
                    }}>Review</Text>
                    <Rating
                        type="star"
                        fractions={1}
                        ratingBackgroundColor='transparent'
                        startingValue={3.6}
                       
                        imageSize={responsiveHeight(2)}
                        onFinishRating={this.ratingCompleted}
                        style={{
                        position: "absolute",
                        right: "3%",
                        top: responsiveHeight(20),
                        backgroundColor: "transparent"
                    }}/>
                </View>
                <Text
                    style={{
                    left: "3%",
                    marginTop: responsiveHeight(2),
                    fontSize: responsiveFontSize(2.2),
                    fontWeight: "500",
                    color: "black"
                }}>Name</Text>
                <Text
                    style={{
                    left: "3%",
                    marginTop: responsiveHeight(1.2),
                    fontSize: responsiveFontSize(2),
                    color: "black"
                }}>Ali Hussain</Text>
                <View
                    style={{
                    height: 1,
                    width: "100%",
                    backgroundColor: "#DFDFDF",
                    marginTop: responsiveHeight(1.8)
                }}></View>
                <Text
                    style={{
                    left: "3%",
                    marginTop: responsiveHeight(1.5),
                    fontSize: responsiveFontSize(2.2),
                    fontWeight: "500",
                    color: "black"
                }}>Shift</Text>
                <Text
                    style={{
                    left: "3%",
                    marginTop: responsiveHeight(1.2),
                    fontSize: responsiveFontSize(2),
                    color: "black"
                }}>08:00 AM - 06:00 PM</Text>
                <View
                    style={{
                    height: 1,
                    width: "100%",
                    backgroundColor: "#DFDFDF",
                    marginTop: responsiveHeight(1.8)
                }}></View>
                <Text
                    style={{
                    left: "3%",
                    marginTop: responsiveHeight(1.5),
                    fontSize: responsiveFontSize(2.2),
                    fontWeight: "500",
                    color: "black"
                }}>Site</Text>
                <Text
                    style={{
                    left: "3%",
                    marginTop: responsiveHeight(1.2),
                    fontSize: responsiveFontSize(2),
                    color: "black"
                }}>Indore</Text>
                <View
                    style={{
                    height: 1,
                    width: "100%",
                    backgroundColor: "#DFDFDF",
                    marginTop: responsiveHeight(1.8)
                }}></View>
                <ExpandableList
                    dataSource={this.state.data}
                    headerKey="title"
                    memberKey="member"
                    renderRow={this._renderRow}
                    renderSectionHeaderX={this._renderSection}/>
            </Container>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        backgroundColor: "#FFF"
    },
    header: {
        backgroundColor: "#D3B749"
    },
    headerTitle: {
        backgroundColor: "transparent",
        alignSelf: "center",
        color: "white"
    }
});
export default SupervisorDetail;
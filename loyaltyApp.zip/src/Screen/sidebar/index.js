import React, {Component} from "react";
import {Image, Alert, AsyncStorage, BackHandler, StatusBar, TouchableOpacity} from "react-native";
const GLOBAL = require("../lib/Global.js");

import {
  Content,
  Text,
  List,
  ListItem,
  Icon,
  Container,
  Left,
  Right,
  Badge,
  Button,
  View,
  StyleProvider,
  getTheme,
  variables
} from "native-base";
import {NavigationActions} from "react-navigation";
import styles from "./style";
import {responsiveHeight, responsiveWidth, responsiveFontSize} from 'react-native-responsive-dimensions';


const datas = [
  {
    name: "Home",
    route: "Home",
    icon: "home",
    bg: "#C5F442"
  }, {
    name: "Profile",
    route: "Profile",
    icon: "md-camera",
    bg: "#C5F442"
  }, {
    name: "Settings",
    route: "Settings",
    icon: "settings",
    bg: "#C5F442"
  }, {
    name: "Logout",
    route: "logout",
    icon: "log-out",
    bg: "#C5F442"
  }
];

class SideBar extends Component {
  constructor(props) {
    super(props);
    this.state = {
      shadowOffsetWidth: 1,
      shadowRadius: 4,
      avatarSource: null,
    videoSource: null
    };
  }

componentDidMount() {
  
}

  

  componentDidMount() {
    BackHandler.addEventListener("hardwareBackPress", this.onBackPress);
  }
  componentWillUnmount() {
    BackHandler.removeEventListener("hardwareBackPress", this.onBackPress);
  }
  onBackPress() {
    Alert.alert("AndroidApp", "Are you sure want to quit?", [
      {
        text: "Cancel",
        onPress: () => console.log("Cancel Pressed"),
        style: "cancel"
      }, {
        text: "OK",
        onPress: () => {
          BackHandler.exitApp(0);
        }
      }
    ], {cancelable: false});
    return true;
  }

  render() {
    return (
      <Container>
        <StatusBar barStyle="light-content"/>
        <View
          style={{
          height: 20,
          top: 0,
          width: "100%",
          backgroundColor: "#D3B749"
        }}></View>
        <View
          style={{
          position: "absolute",
          height: "35%",
          top: 20,
          width: "100%",
          borderBottomColor: "#C8C7CC",
          borderBottomWidth:0.6,
          justifyContent: "center",
          alignItems: "center"
        }}>
          <Image
          
            style={{
            borderColor: "#D3B749",
            borderWidth: 1,
            height: responsiveHeight(14.5),
            width: responsiveHeight(14.5),
            borderRadius: responsiveHeight(14.5) / 2
          }}
            source={require('../assets/images/user_img.png')}/>
          <Text
            numberOfLines={2}
            style={{
            width: "94%",
            top: "76.26%",
            position: "absolute",
            color: '#D3B749', 
          }}>sdfj
            lkdfjdjf dfjdfjkdf skfj kdf dfkd fk dfkdfk fkjs dfjjfkdjf dfj kd k f dfjd f fd f
            dfjdkjkf d d f</Text>
        </View>

        <List
          dataArray={datas}
          style={{
          position: "absolute",
          width: "100%",
          top: "39%" 
        }}
          renderRow={data => (
          <ListItem
            button
            onPress={() => {
            console.log("ROUTE " + data.route);
            if (data.route == "logout") {
              Alert.alert("Logout", "Are you sure want to logout?", [
                {
                  text: "Cancel",
                  onPress: () => console.log("Cancel Pressed"),
                  style: "cancel"
                }, {
                  text: "OK",
                  onPress: () => {
                    let resetAction = NavigationActions.reset({
                      index: 0,
                      actions: [NavigationActions.navigate({routeName: "Login"})]
                    });
                    this
                      .props
                      .navigation
                      .dispatch(resetAction);
                      // AsyncStorage.removeItem("userCredential", null);
                  }
                }
              ], {cancelable: false});
            } else {
              this
                .props
                .navigation
                .navigate(data.route);
            }
          }}>
            <Left>
              <Icon
                active
                name={data.icon}
                style={{
                color: "#777",
                fontSize: 24,
                width: 30,
                backgroundColor: "transparent"
              }}/>
              <Text style={styles.text}>{data.name}</Text>
            </Left>
          </ListItem>
        )}/>

      </Container>
    );
  }
}

export default SideBar;

/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */
/*
* All File Import Here
*/
import React, {Component} from 'react';
import {Root} from "native-base";
import {
    Platform,
    StyleSheet,
    Text,
    View,
    Image,
    TextInput,
    Keyboard,
    KeyboardAvoidingView,
    TouchableOpacity,
    NetInfo,
    Alert
} from 'react-native';
import {
    Container,
    Content,
    Header,
    Left,
    Right,
    Body,
    Title
} from "native-base";
// import Orientation from 'react-native-orientation';
import Global from "../lib/Global.js"
import Modal from 'react-native-simple-modal';
import WebServiceHandler from 'react-native-web-service-handler'
import Communicator from "../lib/Communicator.js"
import SplashScreen from "react-native-smart-splash-screen";
import Display from "react-native-display";
import {responsiveHeight, responsiveWidth, responsiveFontSize} from 'react-native-responsive-dimensions';

import CheckBox from 'react-native-modest-checkbox'

export default class Login extends Component {
    static navigationOptions = {
        title: 'Sign In'
    }
    constructor(props) {
        super(props);
        this.state = {
            open: false,
            showPass: true,
            press: false,
            username: "company@mailinator.com",
            password: "123456",
            visible: false,
            enable: false,
            checked: false,
            langBtnColor: "#000000",
            langSelctedBtnColor: "#D6AF21",
            avatarSource: null,
            forgotEmail: ""
        };
        this.focusNextField = this
            .focusNextField
            .bind(this);
        this.LoginService = this
            .LoginService
            .bind(this);
        this.inputs = {};

    }

    focusNextField(key) {
        this
            .inputs[key]
            .focus();
    }
    LoginService() {
        var url = Global.DOMAIN_URL + Global.SERVICE_NAME.USERLOGIN;
        var a = 'Email=' + this
            .state
            .username
            .trim();
        a = a + '&Password=' + this
            .state
            .password
            .trim();
        a = a + '&DeviceType=ios';
        a = a + '&Language=en';
        a = a + '&DeviceToken=';
        a = a + '&DeviceID=1';
        console.log("URL : " + url);
        console.log("URL : " + JSON.stringify(a));

        WebServiceHandler.post(url, {
            Accept: "/application/json",
            "Content-Type": "application/x-www-form-urlencoded"
        }, JSON.stringify(a)).then(val => {
            try {
                // callback(val);
                console.log("Response : " + JSON.stringify(val));
            } catch (e) {
                console.log("Error Communicator: " + e);

            } finally {}
        }).catch(error => {
            console.log("callapi:" + JSON.stringify(error));
        });
    }
    _submitForgotPasswordForm = () => {
        const blankEmailValid = this.state.forgotEmail && this.state.forgotEmail.length > 0
            ? true
            : false;
        const emailValid = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(this.state.forgotEmail);
        if (blankEmailValid) {
            if (emailValid) {} else {
                Communicator('Please enter valid email address');
            }
        } else {
            Communicator('Please enter email address');
        }
    }

    _submitForm = () => {
        const {username, password} = this.state;

        const blankEmailValid = username && username.length > 0
            ? true
            : false;
        const emailValid = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(username);
        const blankPasswordValid = password && password.length > 0
            ? true
            : false;
        const passwordLengthValid = password && password.length >= 6
            ? true
            : false;
        if (blankEmailValid) {
            if (emailValid) {
                if (blankPasswordValid) {
                    if (passwordLengthValid) {
                        if (Global.isConnected) {
 
                         const {navigate} = this.props.navigation; navigate("Drawer");
                           // this.LoginService();

                        } else {
                            this
                            Communicator("Please check your internet connection.");
                        }

                    } else {
                        Communicator("Password should have atleast 6 characters");
                    }
                } else {
                    Communicator("Pleaser enter password");
                }
            } else {
                Communicator("Please enter valid Email");
            }
        } else {
            Communicator('Please enter email address');
        }
    }
    componentDidMount() {

        //  Orientation.lockToPortrait();

        SplashScreen.close({animationType: SplashScreen.animationType.scale, duration: 850, delay: 500});
        this.setState({enable: true});

    }

    render() {
        return (

            <View
                style={{
                backgroundColor: "#EDEEF0",
                height: "100%"
            }}
                scrollEnabled={false}
                onStartShouldSetResponderCapture={e => {
                console.log("e.native " + e.nativeEvent.target);
                if (e.nativeEvent.target != 22 && e.nativeEvent.target != 17 && e.nativeEvent.target != 20 && e.nativeEvent.target != 18 && e.nativeEvent.target != 16 && e.nativeEvent.target != 19) {
                    Keyboard.dismiss();
                }
            }}>
                <Display
                    enable={this.state.enable}
                    enterDuration={2000}
                    enter="fadeIn"
                    style={styles.logoVW}>
                    <Image source={require("../assets/images/logoLogin.png")}/>
                </Display>
                <Text style={styles.signInLbl}>Sign In</Text>
                <View style={styles.lineImg}></View>
                <Text style={styles.langLbl}>Please select language</Text>
                <View
                    style={{
                    position: "absolute",
                    top: "37%",
                    width: "48%",
                    alignSelf: "center",
                    height: "6%",
                    alignItems: "center",
                    justifyContent: "center"
                }}>
                    <TouchableOpacity
                        style={{
                        position: "absolute",
                        left: 0,
                        width: "46%",
                        height: "100%",
                        justifyContent: "center"
                    }}
                        onPress={() => {
                        this.setState({langSelctedBtnColor: "#D6AF21"});
                        this.setState({langBtnColor: "#000000"});
                    }}>
                        <Text
                            style={{
                            color: this.state.langSelctedBtnColor,
                            alignSelf: "center",
                            fontSize: responsiveFontSize(2.2)
                        }}>English</Text>
                    </TouchableOpacity>
                    <View
                        style={{
                        position: "absolute",
                        backgroundColor: "black",
                        width: 1,
                        height: "40%",
                        alignSelf: "center"
                    }}></View>
                    <TouchableOpacity
                        style={{
                        position: "absolute",
                        right: 0,
                        width: "46%",
                        height: "100%",
                        justifyContent: "center"
                    }}
                        onPress={() => {
                        this.setState({langSelctedBtnColor: "#000000"});
                        this.setState({langBtnColor: "#D6AF21"});
                    }}>
                        <Text
                            style={{
                            color: this.state.langBtnColor,
                            alignSelf: "center",
                            fontSize: responsiveFontSize(2.2)
                        }}>Arabic</Text>
                    </TouchableOpacity>
                </View>
                <View style={styles.userTextVW}>
                    <Image source={require("../assets/images/send.png")} style={styles.inlineImg}/>
                    <TextInput
                        style={styles.input}
                        placeholder="Email"
                        autoCorrect={false}
                        autoCapitalize={"none"}
                        returnKeyType={"next"}
                        placeholderTextColor="grey"
                        underlineColorAndroid="transparent"
                        onChangeText=
                        { username => this.setState({username}) }
                        value={this.state.username}
                        ref=
                        { input => { this.inputs["one"] = input; } }
                        onSubmitEditing=
                        { () => { this.focusNextField("two"); } }/>
                </View>
                < View style={styles.pwdTextVW}>
                    <Image source={require("../assets/images/password.png")} style={styles.pwdImg}/>
                    <TextInput
                        style={styles.pwdTF}
                        placeholder="Password"
                        secureTextEntry={true}
                        autoCorrect={false}
                        autoCapitalize={"none"}
                        returnKeyType={"done"}
                        placeholderTextColor="grey"
                        underlineColorAndroid="transparent"
                        onChangeText=
                        { password => this.setState({password}) }
                        value={this.state.password}
                        ref=
                        { input => { this.inputs["two"] = input; } }
                        onSubmitEditing=
                        { () => { this.focusNextField("two"); } }/>
                </View>
                <View style={styles.checkboxView}>

                    <CheckBox
                        checkedImage={require("../assets/images/check.png")}
                        uncheckedImage={require("../assets/images/uncheck.png")}
                        label='Remember Me'
                        checkboxStyle={{
                        width: responsiveHeight(3.8),
                        height: responsiveHeight(3.8)
                    }}
                        checked={this.state.checked}
                        containerStyle={{
                        position: "absolute",
                        left: "5.5%",
                        width: "40%",
                        height: "50%"
                    }}
                        labelStyle={{
                        left: "5.5%",
                        color: "grey",
                        fontSize: responsiveFontSize(1.8)
                    }}
                        onChange={(checked) => {
                        this.setState({
                            checked: !this.state.checked
                        })
                    }}/>
                    <TouchableOpacity
                        style={{
                        position: "absolute",
                        width: "40%",
                        right: 15 * Global.HEIGHT_FACTOR,
                        alignSelf: "center",
                        alignItems: "flex-end",
                        justifyContent: "center",
                        height: "50%"
                    }}
                        onPress={() => this.setState({open: true})}>
                        <Text
                            style={{
                            color: "grey",
                            fontSize: responsiveFontSize(1.8)
                        }}>Forgot Password?</Text>
                    </TouchableOpacity>

                </View>

                <TouchableOpacity style={styles.loginBtn} onPress={this._submitForm}>
                    <Text style={styles.logintext}>SIGN IN</Text>
                </TouchableOpacity>
                <Modal
                    offset={this.state.offset}
                    open={this.state.open}
                    modalDidOpen=
                    { () => console.log('modal did open') }
                    modalDidClose=
                    { () => this.setState({open: false}) }
                    style={{
                    alignItems: 'center'
                }}>
                    <View>
                        <Text
                            style={{
                            fontSize: responsiveFontSize(3),
                            marginBottom: 8,
                            alignSelf: "center",
                            color: "#D4A707"
                        }}>Forgot Password</Text>
                        <Text
                            style={{
                            fontSize: responsiveFontSize(1.6),
                            marginBottom: 10,
                            textAlign: "center",
                            alignSelf: "center",
                            color: "#000",
                            width: "94%"
                        }}>{"Please enter your registered email address used  to create your account."}</Text>

                        <TextInput
                            style={styles.forgotTF}
                            placeholder="Email"
                            autoCorrect={false}
                            autoCapitalize={"none"}
                            returnKeyType={"done"}
                            placeholderTextColor="grey"
                            underlineColorAndroid="transparent"
                            onChangeText=
                            { forgotEmail => this.setState({forgotEmail}) }
                            value={this.state.forgotEmail}
                            ref=
                            { input => { this.inputs["forgotEmail"] = input; } }
                            onSubmitEditing=
                            { () => { } }/>
                        <View
                            style={{
                            marginTop: 10,
                            alignSelf: "center",
                            marginBottom: 10,
                            height: responsiveHeight(6.5),
                            width: "94%"
                        }}>
                            <TouchableOpacity
                                style={{
                                height: "100%",
                                borderRadius: 6,
                                width: "46%",
                                left: 0,
                                backgroundColor: "#D5A40A",
                                justifyContent: "center"
                            }}
                                onPress={this._submitForgotPasswordForm}>
                                <Text
                                    style={{
                                    alignSelf: "center",
                                    color: "white"
                                }}>Request</Text>
                            </TouchableOpacity>
                            <TouchableOpacity
                                style={{
                                position: "absolute",
                                height: "100%",
                                borderRadius: 6,
                                width: "46%",
                                right: 0,
                                backgroundColor: "#000",
                                justifyContent: "center"
                            }}
                                onPress={() => this.setState({open: false})}>
                                <Text
                                    style={{
                                    alignSelf: "center",
                                    color: "white"
                                }}>Cancel</Text>
                            </TouchableOpacity>
                        </View>

                    </View>
                </Modal>
            </View>

        );
    }
}
const styles = StyleSheet.create({
    headerVW: {
        backgroundColor: "#f8f8f8"
    },
    logoVW: {
        position: "absolute",
        top: "5.28%",
        // justifyContent: 'center',
        alignSelf: 'center'
    },
    signInLbl: {
        fontWeight: "normal",
        position: "absolute",
        alignSelf: 'center',
        color: "#D4A707",
        top: "22.50%",
        fontSize: responsiveFontSize(4)
    },
    lineImg: {
        position: "absolute",
        top: "30%",
        backgroundColor: "#ffffff",
        height: 1,
        width: "100%"
    },
    langLbl: {
        fontWeight: "normal",
        position: "absolute",
        alignSelf: 'center',
        color: "#000",
        top: "33%",
        fontSize: responsiveFontSize(1.3)
    },
    userTextVW: {
        position: "absolute",
        top: "45.42%",
        //top: 120 * Global.HEIGHT_FACTOR,
        flexDirection: "row",
        backgroundColor: "white",
        left: 0,
        right: 0,
        height: "9.33%",
        alignItems: "center"
    },
    inlineImg: {
        position: "absolute",
        left: "5.5%"
    },
    input: {
        position: "absolute",
        left: "16.5%",
        //backgroundColor: "rgba(255, 255, 255, 0.4)",
        width: "80%",
        height: "100%",
        alignSelf: "center",
        paddingLeft: 0,
        color: "#282828",
        fontSize: responsiveFontSize(2)
    },
    pwdTextVW: {
        position: "absolute",
        top: "55.00%",
        // top: 121 * Global.HEIGHT_FACTOR,
        flexDirection: "row",
        backgroundColor: "white",
        width: "100%",
        //height: 50 * Global.HEIGHT_FACTOR,
        height: "9.33%",
        alignItems: "center"
    },
    pwdImg: {
        position: "absolute",
        left: "5.5%"
    },
    pwdTF: {
        position: "absolute",
        left: "16.5%",
        width: "80%",
        height: "100%",
        alignSelf: "center",
        paddingLeft: 0,
        color: "#282828",
        fontSize: responsiveFontSize(2)
    },
    checkboxView: {

        position: "absolute",
        top: "64.70%",
        height: "8.5%",
        width: "100%",
        justifyContent: "center"
    },
    checkbox: {
        position: "absolute",
        left: 100

    },
    loginBtn: {
        height: "9.33%",
        // height: 50 * Global.HEIGHT_FACTOR,
        width: "100%",
        backgroundColor: "#D5A40A",
        top: "73.50%",
        justifyContent: "center",
        alignItems: "center"
    },
    logintext: {
        fontWeight: "300",
        fontSize: responsiveFontSize(3.2),
        color: "#FFFFFF"
    },
    forgotTF: {
        marginBottom: 10,
        borderColor: "#dcdcdc",
        borderWidth: 1,
        borderRadius: 6,
        width: "94%",
        height: responsiveHeight(7),
        alignSelf: "center",
        paddingLeft: 10,
        color: "#282828",
        fontSize: responsiveFontSize(2)
    }
});
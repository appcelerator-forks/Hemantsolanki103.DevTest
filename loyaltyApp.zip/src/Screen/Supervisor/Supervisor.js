import React, {Component, PropTypes} from "react";
import {TouchableOpacity, StyleSheet, Image, View, StatusBar} from "react-native";
import ExpandableList from 'react-native-expandable-section-flatlist';
import {responsiveHeight, responsiveWidth, responsiveFontSize} from 'react-native-responsive-dimensions';

import {
    Container,
    Header,
    Title,
    Content,
    Footer,
    FooterTab,
    Button,
    Left,
    Right,
    Body,
    Icon,
    Text,
    ActionSheet,
    Badge,
    Card,
    Thumbnail,
    CardItem,
    Input,
    Item,
    Form,
    Label,
    ListItem,
    List,
    Segment,
    SwipeRow
} from "native-base";
import {SearchBar} from 'react-native-elements'
const workbenchData = [
    {
        title: 'ABCD',
        member: [
            {
                title: '组1--row1'
            }, {
                title: '组1--row2'
            }, {
                title: '组1--row3'
            }, {
                title: '组1--row4'
            }, {
                title: '组1--row5'
            }, {
                title: '组1--row6'
            }
        ]
    }, {
        title: 'cdef',
        member: [
            {
                title: '组2--row1'
            }, {
                title: '组2--row2'
            }, {
                title: '组2--row3'
            }, {
                title: '组2--row4'
            }
        ]
    }, {
        title: 'ghij',
        member: [
            {
                title: '组3--row1'
            }, {
                title: '组3--row2'
            }, {
                title: '组3--row3'
            }
        ]
    }, {
        title: 'klmn',
        member: [
            {
                title: '组4--row1'
            }
        ]
    }, {
        title: 'opqrst',
        member: [
            {
                title: '组5--row1'
            }, {
                title: '组5--row2'
            }, {
                title: '组5--row3'
            }, {
                title: '组5--row4'
            }, {
                title: '组5--row5'
            }
        ]
    }
];
const GLOBAL = require("../lib/Global.js");

class Supervisor extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            data: [],
            text: ""
        };

        this.searchInputOnChange = this
            .searchInputOnChange
            .bind(this);
    }

    _onPress = (type, i) => {
        if (type == "image") {
            this
                .props
                .navigation
                .navigate("SupervisorDetail"); 
        }
    }
    _onHeaderPress = (e) => {
        console.log("SECTION : " + e.nativeEvent);
    }
    componentDidMount() {
        console.log("--------2--------")
        setTimeout(() => {
            this.setState({data: workbenchData})
        }, 100);
    }
    

    _renderRow = (rowItem, rowId, sectionId) => (
        <View
            style={{
            borderBottomColor: "#dcdcdc",
            borderBottomWidth: 0.5
        }}>
            <Text
                style={{
                marginTop: 8,
                marginBottom: 8,
                left: responsiveWidth(3),
                fontSize: responsiveFontSize(1.5)
            }}>Name: {rowItem.title}</Text>
            <Text
                style={{
                marginBottom: 8,
                left: responsiveWidth(3),
                fontSize: responsiveFontSize(1.5)
            }}>Site: Company</Text>
            <Text
                style={{
                marginBottom: 8,
                left: responsiveWidth(3),
                fontSize: responsiveFontSize(1.5)
            }}>{"Shift: 10:00 AM To 5:00 PM"}</Text>
        </View>
    );
    _renderSection = (section, sectionId) => (
        <View
            style={{
            height: responsiveHeight(27.72),
            borderBottomColor: "#dcdcdc",
            borderBottomWidth: 0.5
        }}>
            <View
                style={{
                height: responsiveHeight(20.90),
                justifyContent: "center"
            }}>
                <TouchableOpacity
                    onPress={() => this._onPress("image", sectionId)}
                    style={{
                    position: "absolute",
                    left: responsiveWidth(3),
                    height: responsiveHeight(18.50),
                    borderColor: "#E3E3E3",
                    borderWidth: 1,
                    width: responsiveWidth(28.90),
                    alignSelf: "center"
                }}>
                    <Image
                        style={{
                        height: "100%",
                        width: "100%"
                    }}
                        source={require('../assets/images/back_transparent.png')}></Image>
                    <View
                        style={{
                        position: "absolute",
                        height: "22%",
                        width: "100%",
                        bottom: 0,
                        backgroundColor: "rgba(211,183,73,0.6)",
                        alignItems: "center",
                        justifyContent: "center"
                    }}>
                        <Text
                            style={{
                            fontSize: responsiveFontSize(1.6),
                            color: "black"
                        }}>View Summary</Text>
                    </View>
                </TouchableOpacity>
                <Text
                    numberOfLines={1}
                    style={{
                    position: "absolute",
                    left: responsiveWidth(35),
                    backgroundColor: "transparent",
                    top: responsiveHeight(1.2),
                    color: "black",
                    width: responsiveWidth(62),
                    fontSize: responsiveFontSize(2.5)
                }}>{section}</Text>

                <Text
                    numberOfLines={1}
                    style={{
                    position: "absolute",
                    left: responsiveWidth(35),
                    backgroundColor: "transparent",
                    top: responsiveHeight(6.5),
                    color: "black",
                    width: responsiveWidth(62),
                    fontSize: responsiveFontSize(1.5)
                }}>Mobile Number : 9770494294</Text>
                <Text
                    numberOfLines={1}
                    style={{
                    position: "absolute",
                    left: responsiveWidth(35),
                    backgroundColor: "transparent",
                    top: responsiveHeight(9.68),
                    color: "black",
                    width: responsiveWidth(62),
                    fontSize: responsiveFontSize(1.5)
                }}>Site : Company bame</Text>
                <TouchableOpacity
                    onPress={() => this._onPress("rating", sectionId)}
                    style={{
                    position: "absolute",
                    left: responsiveWidth(35),
                    backgroundColor: "#D3B749",
                    top: responsiveHeight(13.75),
                    width: responsiveWidth(25.75),
                    height: responsiveHeight(3.75),
                    justifyContent: "center",
                    alignItems: "center",
                    borderRadius: 5
                }}>
                    <Text
                        style={{
                        color: "white",
                        fontSize: responsiveFontSize(1.4)
                    }}>Rating</Text>
                </TouchableOpacity>
                <TouchableOpacity
                    onPress={() => this._onPress("complaint", sectionId)}
                    style={{
                    position: "absolute",
                    left: responsiveWidth(66),
                    backgroundColor: "#D3B749",
                    top: responsiveHeight(13.75),
                    width: responsiveWidth(25.75),
                    height: responsiveHeight(3.75),
                    justifyContent: "center",
                    alignItems: "center",
                    borderRadius: 5
                }}>
                    <Text
                        style={{
                        color: "white",
                        fontSize: responsiveFontSize(1.4)
                    }}>File a Complaint</Text>
                </TouchableOpacity>
            </View>
            <View
                style={{
                height: responsiveHeight(5.40),
                backgroundColor: "#E3E3E3",
                width: "100%",
                justifyContent: "center"
            }}>
                <Text
                    style={{
                    left: responsiveWidth(3),
                    color: "black",
                    fontSize: responsiveFontSize(1.6)
                }}>List of associcated guards</Text>
                <Image
                    style={{
                    position: "absolute",
                    right: responsiveWidth(3)
                }}
                    source={require('../assets/images/open.png')}></Image>
            </View>
        </View>
    );

    searchInputOnChange(text) {

        console.log("TEXT :: " + text)

        //var promise = new Promise(function (resolve, reject) { resolve(result); });
        let result = workbenchData.filter(workbenchData => {
            const fullName = `${workbenchData
                .title
                .toLowerCase()}`;
            return fullName.indexOf(text.toLowerCase()) > -1;
        });
        this.setState({data: result});
        // promise.then(function (res) { console.log('Got data! Promise fulfilled.' +
        // JSON.stringify(res));    this.setState({text:res}); }, function (error) {
        // console.log('Promise rejected.'); console.log(error.message); }.bind(this));

    }

    render() {

        return (
            <Container style={styles.container}>
                <Header style={styles.header}>
                    <Left style={{
                        flex: 0.2
                    }}>
                        <Button
                            transparent
                            style={{
                            width: "100%",
                            height: "100%"
                        }}
                            onPress={() => this.props.navigation.goBack()}>
                            <Icon
                                name="ios-arrow-back"
                                style={{
                                color: "white"
                            }}/>
                        </Button>
                    </Left>
                    <Body
                        style={{
                        flex: 0.8,
                        alignSelf: "center"
                    }}>
                        <Title style={styles.headerTitle}>
                            Supervisor
                        </Title>
                    </Body>
                    <Right
                        style={{
                        right: 0,
                        flex: 0.2
                    }}></Right >
                </Header>
                <StatusBar barStyle="light-content"/>
                <SearchBar
                    placeholder='Search...'
                    containerStyle={{
                    backgroundColor: "#D3B749"
                }}
                    inputStyle={{
                    backgroundColor: "#fff"
                }}
                    onChangeText={this.searchInputOnChange}/>

                <ExpandableList
                    dataSource={this.state.data}
                    headerKey="title"
                    memberKey="member"
                    renderRow={this._renderRow}
                    renderSectionHeaderX={this._renderSection}/>
            </Container>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        backgroundColor: "#FFF"
    },
    header: {
        backgroundColor: "#D3B749"
    },
    headerTitle: {
        backgroundColor: "transparent",
        alignSelf: "center",
        color: "white"
    }
});
export default Supervisor;
import React, {Component, PropTypes} from "react";
import {TouchableOpacity, StyleSheet, StatusBar, Image, View} from "react-native";
//import { Actions } from "react-native-router-flux";
import {
    Container,
    Header,
    Title,
    Content,
    Footer,
    FooterTab,
    Button,
    Left,
    Right,
    Body,
    Icon,
    Text,
    ActionSheet,
    Badge,
    Card,
    Thumbnail,
    CardItem,
    Input,
    Item,
    Form,
    Label,
    ListItem,
    List,
    Segment,
    SwipeRow
} from "native-base";
import {responsiveHeight, responsiveWidth, responsiveFontSize} from 'react-native-responsive-dimensions';
const GLOBAL = require("../lib/Global.js");
import ResponsiveImage from 'react-native-responsive-image';
class Home extends React.Component {

    componentDidMount() {}

    render() {
        return (
            <Container style={styles.container}>

                <Header style={styles.header}>
                    <Left
                        style={{
                        left: 0,
                        flex: 0.2 
                    }}>
                        <Button
                            transparent
                            style={{
                            width:"100%",
                            height:"100%"
                        }}
                            onPress={() => this.props.navigation.navigate("DrawerOpen")}>
                            <Icon
                                name="md-menu"
                                style={{
                                color: "white"
                            }}/>
                        </Button>
                    </Left>
                    <Body
                        style={{
                        flex: 0.8,
                        alignSelf: "center"
                    }}>
                        <Title style={styles.headerTitle}>
                            Home
                        </Title>
                    </Body>
                    <Right
                        style={{
                        right: 0,
                        flex: 0.2
                    }}>
                        <Button
                            transparent
                            onPress=
                            { () => this.props.navigation.navigate("Notification") }>
                            <Icon
                                name="ios-notifications-outline"
                                style={{
                                color: "white"
                            }}/>
                        </Button>
                    </Right>
                </Header>
                <StatusBar barStyle="light-content"/>
                <View style={styles.btnContainer}>
                    <Image
                        style={styles.companyImage}
                        source={require('../assets/images/logo.png')}/>
                    <View
                        style={{
                        position: "absolute",
                        top: 0,
                        right: "5.68%",
                        flexDirection: "row",
                        height: "20.5%",
                        justifyContent: "center"
                    }}>
                        <ResponsiveImage
                            initWidth="130"
                            initHeight="102"
                            style={styles.rightLogoImg}
                            source={require('../assets/images/logo.png')}/>
                    </View>
                    <Text style={styles.welcomeLbl}>Welcome,</Text>
                    <Text numberOfLines={1} style={styles.companyNameLbl}>Name</Text>
                    <View style={styles.lineImg}></View>
                    <View style={styles.mainVW}>
                        <View style={styles.topVW}>
                            <TouchableOpacity
                                onPress={() => this.props.navigation.navigate("Supervisor")}
                                style={styles.supervisorBtn}>

                                <ResponsiveImage
                                    initWidth="170"
                                    initHeight="122"
                                    source={require('../assets/images/Supervisor.png')}/>
                            </TouchableOpacity>
                            <TouchableOpacity style={styles.guardBtn}>

                                <ResponsiveImage
                                    initWidth="170"
                                    initHeight="122"
                                    source={require('../assets/images/Guards.png')}/>
                            </TouchableOpacity>
                        </View>
                        <View
                            style={{
                            alignSelf: "center",
                            height: "33%",
                            width: "100%"
                        }}>
                            <TouchableOpacity style={styles.contactUsBtn}>
                                <ResponsiveImage
                                    initWidth="170"
                                    initHeight="122"
                                    source={require('../assets/images/Contactus.png')}/>
                            </TouchableOpacity>
                            <TouchableOpacity style={styles.contractBtn}>
                                <ResponsiveImage
                                    initWidth="170"
                                    initHeight="122"
                                    source={require('../assets/images/Contract.png')}/>
                            </TouchableOpacity>
                        </View>
                        <View
                            style={{
                            bottom: 0,
                            height: "33.33%",
                            width: "100%"
                        }}>
                            <TouchableOpacity style={styles.ratingBtn}>
                                <ResponsiveImage
                                    initWidth="170"
                                    initHeight="122"
                                    source={require('../assets/images/ReviewRating.png')}/>
                            </TouchableOpacity>
                            <TouchableOpacity style={styles.timesheetBtn}>

                                <ResponsiveImage
                                    initWidth="170"
                                    initHeight="122"
                                    source={require('../assets/images/TimeSheet.png')}/>
                            </TouchableOpacity>
                        </View>
                    </View>
                </View>
            </Container>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        backgroundColor: "#000"
    },
    header: {
        backgroundColor: "#D3B749"
    },
    headerTitle: {
        backgroundColor: "transparent",
        alignSelf: "center",
        color: "white"
    },
    btnContainer: {
        position: "absolute",
        top: 64,
        bottom: 0,
        width: "100%"
    },
    companyImage: {
        borderColor: "white",
        borderWidth: 1,
        height: responsiveHeight(8),
        width: responsiveHeight(8),
        borderRadius: responsiveHeight(8) / 2,
        position: "absolute",
        top: "1.86%",
        left: "5.68%"
    },
    rightLogoImg: {
        // position: "absolute",
        alignSelf: "center",
        justifyContent: "center",
        //top: "1.86%", right: "5.68%"
    },
    welcomeLbl: {
        position: "absolute",
        top: "12%",
        left: "5.68%",
        fontSize: responsiveFontSize(1.4),
        color: "white"
    },
    companyNameLbl: {
        position: "absolute",
        top: "14.5%",
        left: "5.68%",
        fontSize: responsiveFontSize(2),
        color: "#D3B749",
        width: "55%"
    },
    lineImg: {
        position: "absolute",
        top: "20.5%",
        width: "100%",
        height: 1,
        backgroundColor: "#D3B749"
    },
    mainVW: {
        position: "absolute",
        top: "20.8%",
        bottom: 0,
        width: "100%"
    },
    topVW: {
        top: 0,
        height: "33.33%",
        width: "100%"
    },
    supervisorBtn: {
        left: 0,
        height: "100%",
        width: "50%",
        justifyContent: "center",
        alignItems: "center"
    },
    guardBtn: {
        position: "absolute",
        right: 0,
        height: "100%",
        width: "50%",
        justifyContent: "center",
        alignItems: "center"
    },
    contactUsBtn: {
        left: 0,
        height: "100%",
        width: "50%",
        justifyContent: "center",
        alignItems: "center"
    },
    contractBtn: {
        position: "absolute",
        right: 0,
        height: "100%",
        width: "50%",
        justifyContent: "center",
        alignItems: "center"
    },
    ratingBtn: {
        left: 0,
        height: "100%",
        width: "50%",
        justifyContent: "center",
        alignItems: "center"
    },
    timesheetBtn: {
        position: "absolute",
        right: 0,
        height: "100%",
        width: "50%",
        justifyContent: "center",
        alignItems: "center"
    }

});
export default Home;
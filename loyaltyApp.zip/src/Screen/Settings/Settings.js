import React, {Component, PropTypes} from "react";
import {TouchableOpacity, StyleSheet, Image, View, StatusBar} from "react-native";
import ExpandableList from 'react-native-expandable-section-flatlist';
import {responsiveHeight, responsiveWidth, responsiveFontSize} from 'react-native-responsive-dimensions';

import {
    Container,
    Header,
    Title,
    Content,
    Footer,
    FooterTab,
    Button,
    Left,
    Right,
    Body,
    Icon,
    Text,
    ActionSheet,
    Badge,
    Card,
    Thumbnail,
    CardItem,
    Input,
    Item,
    Form,
    Label,
    ListItem,
    List,
    Segment,
    SwipeRow
} from "native-base";

const GLOBAL = require("../lib/Global.js");

class Setting extends React.Component {
 
    render() {
        return (
            <Container style={styles.container}>
                <Header style={styles.header}>
                    <Left style={{
                        flex: 0.2
                    }}>
                        <Button
                            transparent
                            onPress={() => this.props.navigation.navigate("DrawerOpen")}>
                            <Icon
                                name="md-menu"
                                style={{
                                color: "white"
                            }}/>
                        </Button>
                    </Left>
                    <Body
                        style={{
                        flex: 0.8,
                        alignSelf: "center"
                    }}>
                        <Title style={styles.headerTitle}>
                            Settings
                        </Title>
                    </Body>
                    <Right
                        style={{
                        right: 0,
                        flex: 0.2
                    }}></Right>
                </Header>
                <StatusBar barStyle="light-content"/>
                
            </Container>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        backgroundColor: "#FFF"
    },
    header: {
        backgroundColor: "#D3B749"
    },
    headerTitle: {
        backgroundColor: "transparent",
        alignSelf: "center",
        color: "white"
    }
});
export default Setting;
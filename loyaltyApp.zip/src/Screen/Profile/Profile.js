import React, {Component, PropTypes} from "react";
import {TouchableOpacity, StyleSheet, Image, View, StatusBar} from "react-native";
import ExpandableList from 'react-native-expandable-section-flatlist';
import {
    Container,
    Header,
    Title,
    Content,
    Footer,
    FooterTab,
    Button,
    Left,
    Right,
    Body,
    Icon,
    Text,
    ActionSheet,
    Badge,
    Card,
    Thumbnail,
    CardItem,
    Input,
    Item,
    Form,
    Label,
    ListItem,
    List,
    Segment,
    SwipeRow
} from "native-base";
import {responsiveHeight} from "react-native-responsive-dimensions";

const GLOBAL = require("../lib/Global.js");

class About extends React.Component {
    render() {
        return (
            <Container style={styles.container}>
                <Header style={styles.header}>
                    <Left style={{
                        flex: 0.2
                    }}>
                        <Button
                            transparent
                            onPress={() => this.props.navigation.navigate("DrawerOpen")}>
                            <Icon
                                name="md-menu"
                                style={{
                                color: "white"
                            }}/>
                        </Button>
                    </Left>
                    <Body
                        style={{
                        flex: 0.8,
                        alignSelf: "center"
                    }}>
                        <Title style={styles.headerTitle}>
                            Profile
                        </Title>
                    </Body>
                    <Right
                        style={{
                        right: 0,
                        flex: 0.2
                    }}></Right>
                </Header>
                <StatusBar barStyle="light-content"/>
                <View
                    style={{
                    backgroundColor: "green",
                    flexDirection: 'row'
                }}>
                    <View
                        style={{
                        marginTop: 10,
                        left: 10,
                        width: "30%",
                        height: 100,
                        backgroundColor: 'powderblue'
                    }}/>

                    <View
                        style={{
                        left: 20,
                        width: "64%",
                        flexDirection: "column",
                        backgroundColor: 'steelblue'
                    }}>
                        <Text
                            style={{
                            marginTop: 10
                        }}>sdjflsdf ldf sfjlsjdflsjklfjsljfsd</Text>

                        <Text
                            style={{
                            marginTop: 10
                        }}>sdf
                            sdfk sdf dsf dsf sdf sfsd sdfsdfs sdfdsfsd sdfsdf sdf sdf fdsf sdfsdf fs flkdf s
                            flksd fs fs flksklfjsjf sdkfkldfj dfklsdklf dslkfdl fdf d fdf jlkd fl df df fdf
                            df kldfldjf df</Text>
                    </View>
                </View>

            </Container>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        backgroundColor: "#FFF"
    },
    header: {
        backgroundColor: "#D3B749"
    },
    headerTitle: {
        backgroundColor: "transparent",
        alignSelf: "center",
        color: "white"
    }
});
export default About;
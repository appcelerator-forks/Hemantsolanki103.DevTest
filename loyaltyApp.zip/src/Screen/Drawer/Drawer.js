/* @flow */

import React from "react";
import {DrawerNavigator} from "react-navigation";

import Home from "../Home/Home.js";
import Profile from "../Profile/Profile.js";
import Settings from "../Settings/Settings.js";


import SideBar from "../sidebar";

const DrawerExample = DrawerNavigator({
    Home: {
        screen: Home
    },
    Profile: {
        screen: Profile
    },
    Settings: {
        screen: Settings
    }
}, {
    initialRouteName: "Home",
    contentOptions: {
        //activeTintColor: "#e91e63",
        activeBackgroundColor: "#wk3k12",
        inactiveBackgroundColor: "#010101 "
    },
    useNativeAnimations: true,
    contentComponent: props => <SideBar {...props}/>
});

export default DrawerExample;

import React, {Component, PropTypes} from "react";
import {
    TouchableOpacity,
    StyleSheet,
    Image,
    View,
    FlatList,
    StatusBar
} from "react-native";
//import { Actions } from "react-native-router-flux";
import {
    Container,
    Header,
    Title,
    Content,
    Footer,
    FooterTab,
    Button,
    Left,
    Right,
    Body,
    Icon,
    Text,
    ActionSheet,
    Badge,
    Card,
    Thumbnail,
    CardItem,
    Input,
    Item,
    Form,
    Label,
    ListItem,
    List,
    Segment,
    SwipeRow
} from "native-base";
import {responsiveHeight,responsiveFontSize, responsiveWidth} from "react-native-responsive-dimensions";

const GLOBAL = require("../lib/Global.js");

class Notification extends React.Component {

    _keyExtractor = (item, index) => item;

    _onPressItem = (item) => {
        console.log(JSON.stringify(item));
        // updater functions are preferred for transactional updates

    };

    _renderItem = ({item}) => (<MyListItem
        item={item}
        onPressItem={this._onPressItem}
       />);
    render() {
        var items = [
            {
                title: "Timesheet Open",
                date: "25-12-2017",
                shift: "08:00 AM To 5:00 PM"
            }, {
                title: "Contact Info",
                date: "25-12-2017",
                shift: "08:00 AM To 5:00 PM"
            }, {
                title: "Timesheet Update",
                date: "25-12-2017",
                shift: "08:00 AM To 5:00 PM"
            }
        ];

        return (
            <Container style={styles.container}>
                <Header style={styles.header}>
                    <Left style={{
                        flex: 0.2
                    }}>
                        <Button  transparent
                            style={{ 
                            width: "100%",
                            height: "100%"
                        }}
                            onPress={() => this.props.navigation.goBack()}>
                            <Icon
                                name="ios-arrow-back"
                                style={{
                                color: "white"
                            }}/> 
                        </Button>
                    </Left>
                    <Body
                        style={{
                        flex: 0.8,
                        alignSelf: "center"
                    }}>
                        <Title style={styles.headerTitle}>
                            Notifications
                        </Title>
                    </Body>
                    <Right
                        style={{
                        right: 0,
                        flex: 0.2
                    }}></Right>
                </Header>
<StatusBar barStyle="light-content"/>
                <FlatList
                    data={items}
                    extraData={this.state}
                    keyExtractor={this._keyExtractor}
                    renderItem={this._renderItem}/>

            </Container>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        backgroundColor: "#FFF"
    },
    header: {
        backgroundColor: "#D3B749"
    },
    headerTitle: {
        backgroundColor: "transparent",
        alignSelf: "center",
        color: "white"
    }
});

class MyListItem extends React.PureComponent {
    _onPress = () => {
        this
            .props
            .onPressItem(this.props.item);
    };

    render() {
        const textColor = this.props.item

         const dateShift = this.props.item.date +"  Shift: "+ this.props.item.shift;
            
        return (
            <TouchableOpacity onPress={this._onPress} style={{
                height:60,
                borderBottomColor:"#dcdcdc",
                borderBottomWidth:1,
                justifyContent:"center",
                height:responsiveHeight(10)
                
            }}>
                <View style={{
                    //position:"absolute",
                    flexDirection:"column",
                    
                    //alignSelf:"center",
                    left:responsiveWidth(3.12),
                    
                    width:"88%"
                }}>
                    <Text
                    numberOfLines={1}
                    style={{
                        marginTop:0,
                        fontSize: responsiveFontSize(2.4)
                    }}>
                        {textColor.title}
                    </Text>
                    <Text style={{
                        marginTop:10,
                        fontSize: responsiveFontSize(1.8)
                    }}>
                        {dateShift}   
                    </Text>
                    
                </View>
                <Icon style={{position:"absolute",right:10,color:"#DCDCDE"}}  name="ios-arrow-forward-outline"></Icon>
            </TouchableOpacity>
        );
    }
}
export default Notification;
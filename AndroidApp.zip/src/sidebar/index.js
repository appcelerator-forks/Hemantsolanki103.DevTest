import React, { Component } from "react";
import { Image, Alert, AsyncStorage, BackHandler } from "react-native";

import {
  Content,
  Text,
  List,
  ListItem,
  Icon,
  Container,
  Left,
  Right,
  Badge,
  Button,
  View,
  StyleProvider,
  getTheme,
  variables
} from "native-base";
import { NavigationActions } from "react-navigation";
import styles from "./style";

const drawerCover = require("./wallpaper.png");

const drawerImage = require("./wallpaper.png");

const datas = [
  {
    name: "Home",
    route: "Home",
    icon: "home",
    bg: "#C5F442"
  },
  {
    name: "About",
    route: "About",
    icon: "easel",
    bg: "#C5F442"
  },
  {
    name: "Logout",
    route: "logout",
    icon: "log-out",
    bg: "#C5F442"
  }
];
const GLOBAL = require("../Globals/Globals.js");
class SideBar extends Component {
  constructor(props) {
    super(props);
    this.state = {
      shadowOffsetWidth: 1,
      shadowRadius: 4
    };
  }

  componentDidMount() {
    BackHandler.addEventListener("hardwareBackPress", this.onBackPress);
  }
  componentWillUnmount() {
    BackHandler.removeEventListener("hardwareBackPress", this.onBackPress);
  }
  onBackPress() {
    Alert.alert(
      "AndroidApp",
      "Are you sure want to quit?",
      [
        {
          text: "Cancel",
          onPress: () => console.log("Cancel Pressed"),
          style: "cancel"
        },
        {
          text: "OK",
          onPress: () => {
            BackHandler.exitApp(0);
          }
        }
      ],
      { cancelable: false }
    );
    return true;
  }

  render() {
    return (
      <Container>
        <Content
          bounces={false}
          style={{ flex: 1, backgroundColor: "#fff", top: -1 }}
        >
          <Image source={drawerCover} style={styles.drawerCover}>
            <Image square style={styles.drawerImage} source={drawerImage} />
          </Image>
          <List
            dataArray={datas}
            renderRow={data => (
              <ListItem
                button
                onPress={() => {
                  console.log("ROUTE " + data.route);
                  if (data.route == "logout") {
                    Alert.alert(
                      "Logout",
                      "Are you sure want to logout?",
                      [
                        {
                          text: "Cancel",
                          onPress: () => console.log("Cancel Pressed"),
                          style: "cancel"
                        },
                        {
                          text: "OK",
                          onPress: () => {
                            const backAction = NavigationActions.back({
                              key: "Drawer"
                            });
                            this.props.navigation.dispatch(backAction);
                            this.props.navigation.dispatch(
                              NavigationActions.back()
                            );
                            this.props.navigation.dispatch(
                              NavigationActions.back()
                            );
                            AsyncStorage.removeItem("userCredential", null);
                          }
                        }
                      ],
                      { cancelable: false }
                    );
                  } else {
                    this.props.navigation.navigate(data.route);
                  }
                }}
              >
                <Left>
                  <Icon
                    active
                    name={data.icon}
                    style={{
                      color: "#777",
                      fontSize: 24,
                      width: 30,
                      backgroundColor: "transparent"
                    }}
                  />
                  <Text style={styles.text}>{data.name}</Text>
                </Left>
                {data.types && (
                  <Right style={{ flex: 1 }}>
                    <Badge
                      style={{
                        borderRadius: 3,
                        height: 25,
                        width: 72,
                        backgroundColor: data.bg
                      }}
                    >
                      <Text
                        style={styles.badgeText}
                      >{`${data.types} Types`}</Text>
                    </Badge>
                  </Right>
                )}
              </ListItem>
            )}
          />
        </Content>
      </Container>
    );
  }
}

export default SideBar;

/* @flow */

import React from "react";
import { DrawerNavigator } from "react-navigation";

import Home from "./components/home/Home.js";
import About from "./components/about/About.js";
import Login from "./components/login/login.js";
import Tab from "./components/TabController/FooterTabController.js";

import SideBar from "./sidebar";

const DrawerExample = DrawerNavigator(
  {
    Home: { screen: Home },
    About: { screen: About },
    Tab: { screen: Tab }
  },
  {
    initialRouteName: "Tab",
    contentOptions: {
      //activeTintColor: "#e91e63",
      activeBackgroundColor: "#wk3k12",
      inactiveBackgroundColor: "#010101 "
    },
    useNativeAnimations: true,
    contentComponent: props => <SideBar {...props} />
  }
);

export default DrawerExample;

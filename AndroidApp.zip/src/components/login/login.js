/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component, PropTypes } from "react";
import Dimensions from "Dimensions";
import {
  AppRegistry,
  StyleSheet,
  View,
  Text,
  Image,
  Easing,
  KeyboardAvoidingView,
  ActivityIndicator,
  TouchableOpacity,
  TextInput,
  StatusBar,
  Alert,
  ToastAndroid,
  Platform,
  TouchableHighlight,
  Keyboard,
  TextInputState,
  AsyncStorage,
  Animated,
  NetInfo
} from "react-native";
// import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view'

import { Actions } from "react-native-router-flux";
import KeyboardSpacer from "react-native-keyboard-spacer";
import Toast from "react-native-simple-toast";
const GLOBAL = require("../../Globals/Globals.js");
const Communicator = require("../../Globals/Communicator.js");
const DEVICE_WIDTH = Dimensions.get("window").width;
const DEVICE_HEIGHT = Dimensions.get("window").height;
const HEIGHT_FACTOR = DEVICE_WIDTH / 320;
const MARGIN = 40;
const usernameValue = "";
const pwdValue = "";
const BusyIndicator = require("react-native-busy-indicator");
const loaderHandler = require("react-native-busy-indicator/LoaderHandler");
class login extends Component {
  constructor(props) {
    super(props);
    this.state = {
      showPass: true,
      press: false,
      username: "",
      password: "",
      visible: false
    };
    this.focusNextField = this.focusNextField.bind(this);
    this.inputs = {};
    this.showPass = this.showPass.bind(this);
    this.callapi = this.callapi.bind(this);
    this.buttonAnimated = new Animated.Value(0);
    this.growAnimated = new Animated.Value(0);
    this.navigation = this.props.navigation;
  }
  callapi(data, prop) {
    // Show indicator with message 'Loading'
    Communicator.postService(
      GLOBAL.DOMAIN_URL + GLOBAL.SERVICE_NAME.USERLOGIN,
      data,
      function callback(e) {
        console.log("DATA: " + JSON.stringify(e));
        setTimeout(() => {
          loaderHandler.hideLoader();
        }, 500);
      }
    );
    prop.navigate("Drawer");
  }
  componentWillMount() {
    console.log("------------------------1-----------------------------");
    AsyncStorage.getItem("userCredential", (err, result) => {
      console.log("result " + result);
      if (result != null) {
        const a = JSON.parse(result);
        console.log(a.username);
        console.log(a.password);

        if ((a.username != null) & (a.password != null)) {
          this.setState({ username: a.username });
          this.setState({ password: a.password });

          // this.setState({ visible: true });
          loaderHandler.showLoader("Please wait...");
          this.callapi(
            Communicator.loginDict(
              a.username,
              a.password,
              "cdnsol",
              "1",
              "22.234234",
              "75.2342343"
            ),
            this.props.navigation
          );
        }
      } else {
        this.state.username = "";
        this.state.password = "";
      }
    });
  }
  componentWillUnmount() {}

  showPass() {
    console.log(this.state.press);
    this.state.press === false
      ? this.setState({ showPass: false, press: true })
      : this.setState({ showPass: true, press: false });
  }

  _submitForm = () => {
    const { username, password } = this.state;

    const blankEmailValid = username && username.length > 0 ? true : false;
    const emailValid = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(
      username
    );
    const blankPasswordValid = password && password.length > 0 ? true : false;
    const passwordLengthValid = password && password.length >= 6 ? true : false;
    if (blankEmailValid) {
      if (emailValid) {
        if (blankPasswordValid) {
          if (passwordLengthValid) {
            loaderHandler.showLoader("Please wait...");
            let userCredential = {
              username: username,
              password: password
            };
            AsyncStorage.setItem(
              "userCredential",
              JSON.stringify(userCredential)
            );

            this.callapi(
              Communicator.loginDict(
                username,
                password,
                "cdnsol",
                "1",
                "22.234234",
                "75.2342343"
              ),
              this.props.navigation
            );
          } else {
            Toast.show("Password should have atleast 6 characters", Toast.LONG);
          }
        } else {
          Toast.show("Pleaser enter password", Toast.LONG);
        }
      } else {
        Toast.show("Please enter valid Email", Toast.LONG);
      }
    } else {
      Toast.show("Please enter Email", Toast.LONG);
      //  Alert.alert("Demo","\nPlease enter Email");
    }
  };

  focusNextField(key) {
    this.inputs[key].focus();
  }

  render() {
    const { navigate } = this.props.navigation;
    return (
      <Image source={require("../images/wallpaper.png")} style={styles.picture}>
        <BusyIndicator />
        <View
          keyboardShouldPersistTaps={true}
          style={{
            flex: 1,
            justifyContent: "flex-start",
            backgroundColor: "transparent"
          }}
          onStartShouldSetResponderCapture={e => {
            console.log("e.native " + e.nativeEvent.target);
            if (e.nativeEvent.target != 27 && e.nativeEvent.target != 24) {
              Keyboard.dismiss();
              //navigate("Drawer", { name: "Jane" });
            }
          }}
        >
          <View
            style={{
              flex: 1,
              alignItems: "center",
              backgroundColor: "transparent"
            }}
          >
            <View style={styles.container}>
              <Image
                source={require("../images/logo.png")}
                style={styles.image}
              />
              <Text style={styles.text}> REACT NATIVE </Text>
            </View>
          </View>
          <View
            style={{
              flex: 1,
              backgroundColor: "transparent"
            }}
          >
            <View
              style={{
                top: 10 * HEIGHT_FACTOR
              }}
            >
              <Image
                source={require("../images/username.png")}
                style={styles.inlineImg}
              />
              <TextInput
                style={styles.input}
                placeholder="Email"
                //secureTextEntry={false}
                autoCorrect={false}
                autoCapitalize={"none"}
                returnKeyType={"next"}
                placeholderTextColor="white"
                underlineColorAndroid="transparent"
                onChangeText={username =>
                  this.setState({
                    username
                  })}
                value={this.state.username}
                ref={input => {
                  this.inputs["one"] = input;
                }}
                onSubmitEditing={() => {
                  // specify the key of the ref, as done in the previous section.
                  this.focusNextField("two");
                }}
              />
            </View>
            <View
              style={{
                top: 30 * HEIGHT_FACTOR
              }}
            >
              <Image
                source={require("../images/password.png")}
                style={styles.inlineImg}
              />
              <TextInput
                style={styles.input}
                placeholder="Password"
                secureTextEntry={this.state.showPass}
                autoCorrect={false}
                autoCapitalize={"none"}
                returnKeyType={"done"}
                placeholderTextColor="white"
                underlineColorAndroid="transparent"
                onChangeText={password =>
                  this.setState({
                    password
                  })}
                value={this.state.password}
                ref={input => {
                  this.inputs["two"] = input;
                }}
              />
              <TouchableOpacity style={styles.btnEye} onPress={this.showPass}>
                <Image
                  style={styles.iconEye}
                  source={require("../images/eye_black.png")}
                />
              </TouchableOpacity>
            </View>
            <TouchableOpacity style={styles.button} onPress={this._submitForm}>
              <Text style={styles.logintext}>LOGIN</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Image>
    );
  }
}

const styles = StyleSheet.create({
  picture: {
    flex: 1,
    width: DEVICE_WIDTH,
    height: DEVICE_HEIGHT,
    resizeMode: "cover",

    backgroundColor: "transparent"
  },
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center"
  },
  text: {
    color: "white",
    fontWeight: "bold",
    backgroundColor: "transparent",
    marginTop: 20,
    fontSize: 15 * HEIGHT_FACTOR
  },
  keyContainer: {
    flex: 1,
    alignItems: "center"
  },
  btnEye: {
    position: "absolute",
    top: 9 * HEIGHT_FACTOR,
    right: 30 * HEIGHT_FACTOR
  },
  iconEye: {
    width: 22 * HEIGHT_FACTOR,
    height: 22 * HEIGHT_FACTOR
    //right: 30 * HEIGHT_FACTOR,
  },
  input: {
    backgroundColor: "rgba(255, 255, 255, 0.4)",
    width: DEVICE_WIDTH - 40 * HEIGHT_FACTOR,
    height: 40 * HEIGHT_FACTOR,
    alignSelf: "center",
    paddingLeft: 45,
    borderRadius: 20 * HEIGHT_FACTOR,
    color: "#ffffff",
    fontSize: 14 * HEIGHT_FACTOR
  },
  inlineImg: {
    position: "absolute",
    width: 22 * HEIGHT_FACTOR,
    height: 22 * HEIGHT_FACTOR,
    left: 30 * HEIGHT_FACTOR,
    top: 9 * HEIGHT_FACTOR
  },
  button: {
    top: 50 * HEIGHT_FACTOR,
    width: DEVICE_WIDTH - 40 * HEIGHT_FACTOR,
    alignItems: "center",
    alignSelf: "center",
    justifyContent: "center",
    backgroundColor: "#F035E0",
    height: 40 * HEIGHT_FACTOR,
    borderRadius: 20 * HEIGHT_FACTOR,
    zIndex: 100
  },
  circle: {
    height: 40 * HEIGHT_FACTOR,
    width: 40 * HEIGHT_FACTOR,
    top: 0,
    borderWidth: 1,
    borderColor: "#F035E0",
    borderRadius: 20 * HEIGHT_FACTOR,
    alignSelf: "center",
    zIndex: 99,
    backgroundColor: "#F035E0"
  },
  logintext: {
    color: "white",
    backgroundColor: "transparent",
    fontSize: 15 * HEIGHT_FACTOR
  }
});
export default login;

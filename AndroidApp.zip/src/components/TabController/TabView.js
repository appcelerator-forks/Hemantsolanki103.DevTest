import React, { Component } from "react";
import BottomNavigation, { Tab } from "react-native-material-bottom-navigation";
import Icon1 from "react-native-vector-icons/MaterialCommunityIcons";
import Icon2 from "react-native-vector-icons/MaterialIcons";

class TabView extends Component {
  render() {
    return (
      <BottomNavigation
        labelColor="#686668"
        rippleColor="#FB9222"
        activeLabelColor="#FB9222"
        backgroundColor="white"
        shifting={false}
        style={{
          height: 56,
          elevation: 8,
          position: "absolute",
          left: 0,
          bottom: 0,
          right: 0,
          borderTopWidth: 2
        }}
        onTabChange={newTabIndex => {
          alert(`New Tab at position ${newTabIndex}`);
          if (newTabIndex == 1) {
            this.props.navigation.navigate("About");
          }
        }}
      >
        <Tab
          //barBackgroundColor="#37474F"
          label="Trucks"
          activeIcon={<Icon1 size={24} color="#FB9222" name="truck" />}
          icon={<Icon1 size={24} color="#686668" name="truck" />}
        />
        <Tab
          //  barBackgroundColor="#00796B"
          label="favourite"
          activeIcon={<Icon1 size={24} color="#FB9222" name="heart" />}
          icon={<Icon1 size={24} color="#686668" name="heart" />}
        />
        <Tab
          //  barBackgroundColor="#5D4037"
          label="Loyalty"
          activeIcon={<Icon1 size={24} color="#FB9222" name="qrcode-scan" />}
          icon={<Icon1 size={24} color="#686668" name="qrcode-scan" />}
        />
        <Tab
          //barBackgroundColor="#3E2723"
          label="Offer"
          activeIcon={<Icon1 size={24} color="#FB9222" name="tag-heart" />}
          icon={<Icon1 size={24} color="#686668" name="tag-heart" />}
        />
      </BottomNavigation>
    );
  }
}
export default TabView;

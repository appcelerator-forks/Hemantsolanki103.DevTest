import React from "react";
import { NavigationComponent } from "react-native-material-bottom-navigation";
import {
  TabNavigator,
  StackNavigator,
  NavigationActions
} from "react-navigation";
import { AppRegistry, Alert } from "react-native";

import Home from "../home/Home.js";
import TruckDetailController from "../home/TruckDetailController.js";
import About from "../about/About.js";
import Loyalty from "../Loyalty/Loyalty.js";
import Offer from "../Offer/Offer.js";
import Icon1 from "react-native-vector-icons/MaterialCommunityIcons";
import Icon2 from "react-native-vector-icons/MaterialIcons";

const HomeNavigation = StackNavigator(
  {
    Home: { screen: Home },
    TruckDetailController: { screen: TruckDetailController }
  },
  {
    initialRouteName: "Home",
    headerMode: "none"
  }
  //TruckDetailController: { screen: TruckDetailController }
);
const FooterTabController = TabNavigator(
  {
    TruckList: { screen: HomeNavigation },
    favouriteList: { screen: About },
    Loyalty: { screen: Loyalty },
    Offer: { screen: Offer }
  },
  {
    tabBarComponent: NavigationComponent,
    tabBarPosition: "bottom",
    animationEnabled: false,
    swipeEnabled: false,

    tabBarOptions: {
      bottomNavigationOptions: {
        labelColor: "#686668",
        rippleColor: "#FB9222",
        activeLabelColor: "#FB9222",
        backgroundColor: "white",
        shifting: false,

        style: {
          height: 56,
          elevation: 8,
          borderTopWidth: 1,
          borderColor: "grey"
        },
        tabs: {
          TruckList: {
            label: "Trucks",
            activeIcon: <Icon1 size={24} color="#FB9222" name="truck" />,
            icon: <Icon1 size={24} color="#686668" name="truck" />,
            onPress: newTabIndex => {
              Alert.alert("newTabIndex");
            }
          },
          favouriteList: {
            label: "favourite",
            activeIcon: <Icon1 size={24} color="#FB9222" name="heart" />,
            icon: <Icon1 size={24} color="#686668" name="heart" />
          },
          Loyalty: {
            label: "Loyalty",
            activeIcon: <Icon1 size={24} color="#FB9222" name="qrcode-scan" />,
            icon: <Icon1 size={24} color="#686668" name="qrcode-scan" />
          },
          Offer: {
            label: "Offer",
            activeIcon: <Icon1 size={24} color="#FB9222" name="tag-heart" />,
            icon: <Icon1 size={24} color="#686668" name="tag-heart" />
          }
        }
      }
    }
  }
);
export default FooterTabController;

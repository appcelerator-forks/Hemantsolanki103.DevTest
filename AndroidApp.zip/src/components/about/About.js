import React, { Component, PropTypes } from "react";
import { TouchableOpacity, StyleSheet, Image, View } from "react-native";
//import { Actions } from "react-native-router-flux";
import {
  Container,
  Header,
  Title,
  Content,
  Footer,
  FooterTab,
  Button,
  Left,
  Right,
  Body,
  Icon,
  Text,
  ActionSheet,
  Badge,
  Card,
  Thumbnail,
  CardItem,
  Input,
  Item,
  Form,
  Label,
  ListItem,
  List,
  Segment,
  SwipeRow
} from "native-base";

const GLOBAL = require("../../Globals/Globals.js");

class About extends React.Component {
  render() {
    return (
      <Container style={styles.container}>
        <Header style={{ backgroundColor: "#FB9222" }}>
          <Left style={{ flex: 0.2, backgroundColor: "transparent" }}>
            <Button
              transparent
              onPress={() => this.props.navigation.navigate("DrawerOpen")}
            >
              <Icon name="menu" />
            </Button>
          </Left>
          <Body
            style={{
              backgroundColor: "transparent",
              alignSelf: "center",
              flex: 1
            }}
          >
            <Title
              style={{ backgroundColor: "transparent", alignSelf: "center" }}
            >
              Favourite
            </Title>
          </Body>
          <View style={{ flex: 0.2, backgroundColor: "transparent" }} />
        </Header>

        <Content padder />
      </Container>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: "#FFF"
  }
});
export default About;

import React, { Component, PropTypes } from "react";
import {
  TouchableOpacity,
  StyleSheet,
  Image,
  View,
  Platform
} from "react-native";
import Dimensions from "Dimensions";
import {
  Container,
  Header,
  Title,
  Content,
  Footer,
  FooterTab,
  Button,
  Left,
  Right,
  Body,
  Text,
  ActionSheet,
  Badge,
  Card,
  Thumbnail,
  CardItem,
  Input,
  Item,
  Form,
  Label,
  ListItem,
  List,
  Segment,
  SwipeRow,
  Switch,
  Radio,
  Picker,
  Separator,
  Icon
} from "native-base";
const GLOBAL = require("../../Globals/Globals.js");
//import { StackNavigator } from "react-navigation";
import PressRipple, { Tab } from "react-native-material-bottom-navigation";
import Icon1 from "react-native-vector-icons/MaterialCommunityIcons";
import Icon2 from "react-native-vector-icons/MaterialIcons";
const DEVICE_WIDTH = Dimensions.get("window").width;
class Home extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedItem: undefined,
      selected1: "key1",
      results: {
        items: []
      }
    };
  }

  onValueChange(value: string) {
    this.setState({
      selected1: value
    });
  }
  render() {
    const { navigate } = this.props.navigation;
    var imageURL =
      "http://m2.cdnsolutionsgroup.com/FoodTruckLocator/Upload/truckimage/Thumbnail_Image_284604a26f4640c8aac69318e434d85a.png";
    var items = [
      {
        name: "Food Truck one sdfkjsd fklsf jsf sjf jsdf kldsjfdj",
        image: imageURL
      },
      {
        name: "Food Truck two",
        image: imageURL
      },
      {
        name: "Chiken Blast Truck",
        image: imageURL
      },
      {
        name: "Paw Bhaji Thadhka Truck",
        image: imageURL
      },
      {
        name: "Spicy Chattori Truck",
        image: imageURL
      },
      {
        name: "Simon Mignolet",
        image: imageURL
      },
      {
        name: "Food Truck one sdfkjsd fklsf jsf sjf jsdf kldsjfdj",
        image: imageURL
      },
      {
        name: "Food Truck two",
        image: imageURL
      },
      {
        name: "Chiken Blast Truck",
        image: imageURL
      },
      {
        name: "Paw Bhaji Thadhka Truck",
        image: imageURL
      },
      {
        name: "Spicy Chattori Truck",
        image: imageURL
      },
      {
        name: "Simon Mignolet",
        image: imageURL
      },
      {
        name: "Food Truck one sdfkjsd fklsf jsf sjf jsdf kldsjfdj",
        image: imageURL
      },
      {
        name: "Food Truck two",
        image: imageURL
      },
      {
        name: "Chiken Blast Truck",
        image: imageURL
      },
      {
        name: "Paw Bhaji Thadhka Truck",
        image: imageURL
      },
      {
        name: "Spicy Chattori Truck",
        image: imageURL
      },
      {
        name: "Simon Mignolet",
        image: imageURL
      },
      {
        name: "Food Truck one sdfkjsd fklsf jsf sjf jsdf kldsjfdj",
        image: imageURL
      },
      {
        name: "Food Truck two",
        image: imageURL
      },
      {
        name: "Chiken Blast Truck",
        image: imageURL
      },
      {
        name: "Paw Bhaji Thadhka Truck",
        image: imageURL
      },
      {
        name: "Spicy Chattori Truck",
        image: imageURL
      },
      {
        name: "Simon Mignolet",
        image: imageURL
      },
      {
        name: "Food Truck one sdfkjsd fklsf jsf sjf jsdf kldsjfdj",
        image: imageURL
      },
      {
        name: "Food Truck two",
        image: imageURL
      },
      {
        name: "Chiken Blast Truck",
        image: imageURL
      },
      {
        name: "Paw Bhaji Thadhka Truck",
        image: imageURL
      },
      {
        name: "Spicy Chattori Truck",
        image: imageURL
      },
      {
        name: "Simon Mignolet",
        image: imageURL
      }
    ];

    return (
      <Container style={styles.container}>
        <Header style={{ backgroundColor: "#FB9222" }}>
          <Left style={{ flex: 0.2, backgroundColor: "transparent" }}>
            <Button
              iconRight
              transparent
              style={{
                //  flex: 1,
                width: 50,
                backgroundColor: "transparent"
              }}
              onPress={() => this.props.navigation.navigate("DrawerOpen")}
            >
              <Icon name="menu" />
            </Button>
          </Left>
          <Body
            style={{
              backgroundColor: "transparent",
              alignSelf: "center",
              flex: 1
            }}
          >
            <Title
              style={{ backgroundColor: "transparent", alignSelf: "center" }}
            >
              Truck List
            </Title>
          </Body>
          {/* <View style={{ flex: 0.2, backgroundColor: "transparent" }} /> */}
          <Right style={{ flex: 0.2, backgroundColor: "transparent" }}>
            <Button iconRight transparent>
              <Icon name="search" />
            </Button>
          </Right>
        </Header>

        <Content>
          <List
            style={{
              left: 0,
              right: 0,
              backgroundColor: "red"
            }}
            dataArray={items}
            renderRow={item => (
              <ListItem
                onPress={() => {
                  // Navigate to a separate movie detail screen
                  this.props.navigation.navigate("TruckDetailController");
                }}
                style={{
                  flex: 1,
                  left: 0,
                  right: 0,
                  height: 180,
                  marginLeft: 0,
                  alignSelf: "stretch",
                  width: DEVICE_WIDTH
                }}
              >
                <Image
                  source={{ uri: item.image }}
                  style={{
                    position: "absolute",
                    height: 180,
                    marginLeft: 0,
                    marginRight: 0,
                    width: DEVICE_WIDTH
                  }}
                >
                  <Text
                    numberOfLines={1}
                    ellipsizeMode={"tail"}
                    style={{
                      position: "absolute",
                      color: "white",
                      left: 15,
                      width: "60%",
                      bottom: 35,
                      fontSize: 16
                    }}
                  >
                    {item.name}
                  </Text>
                  <Text
                    numberOfLines={1}
                    ellipsizeMode={"tail"}
                    style={{
                      position: "absolute",
                      color: "white",
                      left: 15,
                      width: "60%",
                      bottom: 15,
                      fontSize: 12
                    }}
                  >
                    {item.name}
                  </Text>
                  <View
                    style={{
                      position: "absolute",
                      flexDirection: "row",
                      bottom: 6,
                      right: 0,
                      width: "28%",
                      ///  backgroundColor: "red",
                      height: 35
                    }}
                  >
                    <Button
                      transparent
                      style={{
                        flex: 1.2,
                        //backgroundColor: "green",
                        justifyContent: "center",
                        alignSelf: "center"
                      }}
                    >
                      <Image source={require("../images/deselected.png")} />
                    </Button>
                    <Button
                      transparent
                      style={{
                        flex: 1,
                        //  backgroundColor: "pink",
                        justifyContent: "center",
                        alignSelf: "center"
                      }}
                    >
                      <Image source={require("../images/favorite.png")} />
                    </Button>
                    <Button
                      transparent
                      style={{
                        flex: 0.8,
                        //  backgroundColor: "red",
                        justifyContent: "center",
                        alignSelf: "center"
                      }}
                    >
                      <Image source={require("../images/dot.png")} />
                    </Button>
                  </View>
                </Image>
              </ListItem>
            )}
          />
        </Content>
        {/* <Footer>
          <PressRipple
            labelColor="#686668"
            rippleColor="#FB9222"
            activeLabelColor="#FB9222"
            backgroundColor="white"
            shifting={false}
            style={{
              height: 56,
              elevation: 8,
              position: "absolute",
              left: 0,
              bottom: 0,
              right: 0,
              borderTopWidth: 2
            }}
            onTabChange={newTabIndex => {
              alert(`New Tab at position ${newTabIndex}`);
              if (newTabIndex == 1) {
                this.props.navigation.navigate("About");
              }
            }}
          >
            <Tab
              //barBackgroundColor="#37474F"
              label="Trucks"
              activeIcon={<Icon1 size={24} color="#FB9222" name="truck" />}
              icon={<Icon1 size={24} color="#686668" name="truck" />}
            />
            <Tab
              //  barBackgroundColor="#00796B"
              label="favourite"
              activeIcon={<Icon1 size={24} color="#FB9222" name="heart" />}
              icon={<Icon1 size={24} color="#686668" name="heart" />}
            />
            <Tab
              //  barBackgroundColor="#5D4037"
              label="Loyalty"
              activeIcon={
                <Icon1 size={24} color="#FB9222" name="qrcode-scan" />
              }
              icon={<Icon1 size={24} color="#686668" name="qrcode-scan" />}
            />
            <Tab
              //barBackgroundColor="#3E2723"
              label="Offer"
              activeIcon={<Icon1 size={24} color="#FB9222" name="tag-heart" />}
              icon={<Icon1 size={24} color="#686668" name="tag-heart" />}
            />
          </PressRipple>
        </Footer> */}
      </Container>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: "#ECECEC"
  }
});
export default Home;

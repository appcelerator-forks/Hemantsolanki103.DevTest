/*
This is globals file for defingin some parameters for global use in the appplication
*/

module.exports = {
  STORE_KEY: "a56z0fzrNpl^2",
  DOMAIN_URL: "http://m2.cdnsolutionsgroup.com/FoodTruckLocator/api/",
  COLOR: {
    ORANGE: "#C50",
    DARKBLUE: "#0F3274",
    LIGHTBLUE: "#6EA8DA",
    DARKGRAY: "#999"
  },
  SERVICE_NAME: {
    USERLOGIN: "User/UserLogin"
  }
};

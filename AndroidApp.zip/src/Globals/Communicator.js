import WebServiceHandler from "react-native-web-service-handler";
import { Platform, StyleSheet } from "react-native";
// var DeviceInfo = require("react-native-device-info");
const BusyIndicator = require("react-native-busy-indicator");
const loaderHandler = require("react-native-busy-indicator/LoaderHandler");

export function getService(url, data, callback) {
  console.log("URL GET: " + url);
  console.log("DATA GET: " + data);
  WebServiceHandler.get(
    url,
    { Accept: "application/json", "Content-Type": "application/json" },
    null
  )
    .then(val => {
      //console.log("callapi: " + JSON.stringify(val));
      try {
        callback(val);
      } catch (e) {
        console.log("Error Communicator: " + e);
      } finally {
      }
    })
    .catch(error => console.log("callapi:" + JSON.stringify(error)));
}

export function postService(url, data, callback) {
  console.log("URL POST: " + url);
  console.log("DATA POST: " + data);
  WebServiceHandler.post(
    url,
    { Accept: "application/json", "Content-Type": "application/json" },
    data
  )
    .then(val => {
      try {
        callback(val);
      } catch (e) {
        console.log("Error Communicator: " + e);
        setTimeout(() => {
          loaderHandler.hideLoader();
        }, 500);
      } finally {
        setTimeout(() => {
          loaderHandler.hideLoader();
        }, 500);
      }
    })
    .catch(error => {
      console.log("callapi:" + JSON.stringify(error));
      setTimeout(() => {
        loaderHandler.hideLoader();
      }, 500);
    });
}

export function loginDict(
  Emailid,
  Password,
  accessKey,
  Tokenid,
  Latitude,
  Longitude
) {
  var object = {};
  object.Emailid = Emailid;
  object.Password = Password;
  object.accessKey = "cdnsol";
  object.version = "9.0";
  object.DeviceName = "iOS";
  object.DeviceID = "1";
  object.Tokenid = Tokenid;
  object.Latitude = Latitude;
  object.Longitude = Longitude;
  return object;
}
